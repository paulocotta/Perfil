#!/usr/bin/env python3
# -*- coding: utf-8 -*-
if (True):
	import sys; sys.dont_write_bytecode=True
	import os, time, re, logging
	from requests import get, post
	from hashlib import sha256
	from multiprocessing import Process
	from json import dumps
	from flask import Flask, render_template, request, jsonify, redirect, url_for
	from waitress import serve
	sys.path.append(r'/etc/scripts')
	from Global import CleanScreen, Mysql, IsValidEmail, SendMailSmtp, GetCep, SendTgm, IsCPF, IsCNPJ
	logging.basicConfig(level=20, force=True, filename='/tmp/logging.log', filemode='a', format=f'%(asctime)s - %(levelname)s - %(message)s - %(funcName)s - %(lineno)d - {str(os.path.basename(sys.argv[0].strip()))} - %(filename)s')
	headers_ret = {'Content-Type':'application/json', 'Cache-Control':'no-cache', 'Pragma':'no-cache', 'Access-Control-Allow-Origin':'*'}
	headers_req = {'Content-Type':'application/json', 'Cache-Control':'no-cache', 'Pragma':'no-cache', 'User-Agent':'WhatsApp/2.20.201.2 A'}
	headers_mpg = {'Content-Type':'application/json', 'Authorization':'Bearer APP_USR-5486932902974306-051701-45360c292331441c0832fb424541f756-1124985687', 'User-Agent':'MKST 1.0'}
	app = Flask(__name__)
	CleanScreen()
	with open(r'/etc/scripts/UtilApi.py','r') as f: code=f.read(); exec(code.strip());

#:API
@app.route('/', methods=['POST'])
def home():
	#: A função home é utilizada para verificar se a api esta up
	try:
		assert(CheckTokenPublic())
		os.system("((timeout 1m '/etc/scripts/rotinas-sync.sh') >/dev/null 2>&1) &")
		#SendTgm(sbj='Health Check', message='Api is OK')
	except Exception as e: return(dict(service='home', status=f'Failed: {type(e)} {str(e)}'), 500, headers_ret)
	else: return(dict(service='home', status='OK'), 200, headers_ret)
@app.route('/getMaintenance', methods=['POST'])
def getMaintenance(maintenance=False):
	#: A função getMaintenance é utilizada para controlar se a aplicação esta ou não em modo manutenção
	try: assert(CheckTokenPublic())
	except Exception as e: return(dict(service=str(request.path[1:]), status=f'Failed: {type(e)} {str(e)}'), 500, headers_ret)
	else: return(dict(service=str(request.path[1:]), status='OK', maintenance=maintenance), 200, headers_ret)
@app.route('/runAjustes', methods=['POST'])
def runAjustes():
	#: A função runAjustes é utilizada para ajustar os dados cadastrais dos clientes
	try:
		assert(CheckTokenPublic())
		#:CEP
		records=DB.Exec("SELECT * FROM `clientes` WHERE NOT ISNULL(`cep`) AND ISNULL(NULLIF(TRIM(`cidade`),''));")
		assert(records)
		for val in records[0]:
			jcep=GetCep(val['cep'])
			assert(jcep)
			jcep['logradouro'], jcep['bairro'], jcep['localidade'] = jcep['logradouro'].title(), jcep['bairro'].title(), jcep['localidade'].title()
			DB.Exec(f"UPDATE `clientes` SET `logradouro`='{jcep['logradouro']}', `bairro`='{jcep['bairro']}', `cidade`='{jcep['localidade']}', `uf`='{jcep['uf']}' WHERE `id`='{val['id']}' LIMIT 1; COMMIT;")
		else: pass
		#:CNPJ
		records=DB.Exec("SELECT * FROM `clientes` WHERE LENGTH(`cpf_cnpj`)=14 AND `numero` IS NULL;")
		assert(records)
		for val in records[0]:
			r=get(f"https://brasilapi.com.br/api/cnpj/v1/{val['cpf_cnpj']}", timeout=10, allow_redirects=True, headers=headers_req).json()
			if ( r.get('razao_social',None)==None ): continue
			sql="UPDATE IGNORE `clientes` SET `nome`='{}', `cep`='{}', `logradouro`='{}', `numero`='{}', `complemento`='{}', `bairro`='{}', `cidade`='{}', `uf`='{}' WHERE `id`='{}' LIMIT 1; COMMIT;"
			sql=sql.format(str(r['razao_social']).title(), str(r['cep']), str(f"{r['descricao_tipo_de_logradouro']} {r['logradouro']}").title(), str(r['numero']), str(r['complemento']).strip('.').title(),
			str(r['bairro']).title(), str(r['municipio']).title(), str(r['uf']), str(val['id']))
			DB.Exec(sql)
		else: pass
	except Exception as e: return(dict(service=str(request.path[1:]), status=f'Failed: {type(e)} {str(e)}'), 500, headers_ret)
	else: return(dict(service=str(request.path[1:]), status='OK'), 200, headers_ret)
@app.route('/getCep', methods=['POST'])
def getCep():
	#: A função getCep é utilizada para obter o logradouro de um determinado CEP
	try:
		assert(CheckTokenPublic())
		cep=str(request.json['cep']).strip()
		cep=re.sub(r'[^\d]+', str(), cep, 0, re.MULTILINE|re.IGNORECASE|re.DOTALL).strip()
		assert(len(cep)==8), 'CEP é um campo obrigatório'
		jdata=GetCep(cep)
		assert(len(jdata['cep'])==9), 'Unknown'
	except Exception as e: return(dict(service=str(request.path[1:]), status=f'Failed: {type(e)} {str(e)}'), 500, headers_ret)
	else: return(dict(service=str(request.path[1:]), status='OK', jdata=jdata), 200, headers_ret)
@app.route('/getCnpj', methods=['POST'])
def getCnpj():
	#: A função getCnpj é utilizada para obter os dados do CNPJ - Empresa
	try:
		assert(CheckTokenPublic())
		cnpj=str(request.json['cnpj']).strip()
		cnpj=re.sub(r'[^\d]+', str(), cnpj, 0, re.MULTILINE|re.IGNORECASE|re.DOTALL).strip()
		assert(len(cnpj)==14), 'CNPJ é um campo obrigatório'
		r=get(f'https://brasilapi.com.br/api/cnpj/v1/{cnpj}', timeout=10, allow_redirects=True, headers=headers_req).json()
		assert(r)
		r=dict(sorted(r.items()))
	except Exception as e: return(dict(service=str(request.path[1:]), status=f'Failed: {type(e)} {str(e)}'), 500, headers_ret)
	else: return(dict(service=str(request.path[1:]), status='OK', jdata=r), 200, headers_ret)
@app.route('/getBcrypt', methods=['POST'])
def getBcrypt():
	#: A função getBcrypt é utilizada para gerar senha no formato Bcrypt
	try:
		from bcrypt import gensalt, hashpw
		pwd, salt = str(request.json['pwd']).strip(), int(request.json.get('salt',13))
		pwd, salt = pwd.encode('utf-8'), gensalt(salt)
		pwd = hashpw(pwd, salt).strip()
	except Exception as e: return(dict(service=str(request.path[1:]), status=f'Failed: {type(e)} {str(e)}'), 500, headers_ret)
	else: return(pwd, 200, headers_ret)
@app.route('/setCliente', methods=['POST'])
def setCliente():
	#: A função setCliente é utilizada para adicionar um novo cliente
	try:
		assert(CheckTokenPublic())
		login, pwd = str(request.json['login']).strip().lower(), str(request.json['pwd']).strip()
		assert(login and pwd), 'Login e Senha são campos obrigatórios'
		assert(IsValidEmail(login)), 'Login/Email inválido'
		jdata = dict({'login':login, 'pwd':pwd, 'pais':str('BR')})
		jdata = dict(list(DB.Exec(f"CALL `SetCliente`('{dumps(jdata, ensure_ascii=False, default=str)}');"))[0][0])
		assert(int(jdata['id']) in [1,3]), 'Unknown'
		if ( int(jdata['id']) == 1 ):
			sbj, body = CreateMsgMailSetCliente(login)
			assert(sbj is not None), 'Unknown'
			Process(target=SendMailSmtp, args=(None, None, 'Financeiro <financeiro@mktstacks.com>', None, 'cotta.paulo@gmail.com', sbj, body, None)).start()
			SendTgm(sbj='SetCliente', message=login)
	except IndexError: return(dict(service=str(request.path[1:]), status=f'Failed: IndexError'), 500, headers_ret)
	except Exception as e: return(dict(service=str(request.path[1:]), status=f'Failed: {type(e)} {str(e)}'), 500, headers_ret)
	else: return(dict(service=str(request.path[1:]), status='OK', jdata=jdata), 200, headers_ret)
@app.route('/setVerify', methods=['GET'])
def setVerify():
	#: A função setVerify é utilizada para verificar o cadastro do client, após SetCliente
	try:
		idverify = str(request.args['idverify']).strip()
		assert(idverify), 'Id Verify é campo obrigatório'
		jdata = dict({'idverify':idverify})
		jdata = dict(list(DB.Exec(f"CALL `SetVerify`('{dumps(jdata, ensure_ascii=False, default=str)}');"))[0][0])
		assert(int(jdata['id']) in [1,2]), 'Unknown'
		if ( jdata['id'] == 1 ): return(redirect(r'https://beta.mkst.app/login.php', code=302))
	except IndexError: return(dict(service=str(request.path[1:]), status=f'Failed: IndexError'), 500, headers_ret)
	except Exception as e: return(dict(service=str(request.path[1:]), status=f'Failed: {type(e)} {str(e)}'), 500, headers_ret)
	else: return(dict(service=str(request.path[1:]), status='OK', jdata=jdata), 200, headers_ret)
@app.route('/setLostPwd', methods=['POST'])
def setLostPwd():
	#: A função setLostPwd é utilizada para solicitação do reset da senha em caso de esquecimento
	try:
		assert(CheckTokenPublic())
		login = str(request.json['login']).strip().lower()
		assert(login), 'Login é campo obrigatório'
		assert(IsValidEmail(login)), 'Login inválido'
		sql=f"SELECT `login`, SHA2(TRIM(CONCAT('@@',`login`,'@@',`modificado`,DATE_FORMAT(CURDATE(),'%d'))),256) AS `idauth` FROM `clientes` WHERE `status`<>0 AND `login`='{login}' LIMIT 1;"
		jdata = dict(list(DB.Exec(sql))[0][0])
		sbj, body = CreateMsgMailSetLostPwd(jdata)
		assert(sbj is not None), 'Unknown'
		Process(target=SendMailSmtp, args=(None, None, 'Financeiro <financeiro@mktstacks.com>', None, 'cotta.paulo@gmail.com', sbj, body, None)).start()
	except IndexError: return(dict(service=str(request.path[1:]), status=f'Failed: IndexError'), 500, headers_ret)
	except Exception as e: return(dict(service=str(request.path[1:]), status=f'Failed: {type(e)} {str(e)}'), 500, headers_ret)
	else: return(dict(service=str(request.path[1:]), status='OK'), 200, headers_ret)
@app.route('/setResetPwd', methods=['POST'])
def setResetPwd():
	#: A função setResetPwd é utilizada para o reset da senha do cliente
	try:
		assert(CheckTokenPublic())
		login, pwd, idauth = str(request.json['login']).strip().lower(), str(request.json['pwd']).strip(), str(request.json['idauth']).strip()
		assert(IsValidEmail(login)), 'Login inválido'
		assert(len(idauth)==64), 'Id Auth inválido'
		jdata = dict({'login':login, 'pwd':pwd, 'idauth':idauth})
		jdata = dict(list(DB.Exec(f"CALL `ResetPwdCliente`('{dumps(jdata, ensure_ascii=False, default=str)}');"))[0][0])
		assert(int(jdata['id']) in [1,253]), 'Unknown'
	except IndexError: return(dict(service=str(request.path[1:]), status=f'Failed: IndexError'), 500, headers_ret)
	except Exception as e: return(dict(service=str(request.path[1:]), status=f'Failed: {type(e)} {str(e)}'), 500, headers_ret)
	else: return(dict(service=str(request.path[1:]), status='OK', jdata=jdata), 200, headers_ret)
@app.route('/getAccessToken', methods=['POST'])
def getAccessToken():
	#: A função getAccessToken é utilizada para credenciar o cliente (login)
	try:
		assert(CheckTokenPublic())
		login, pwd = str(request.json['login']).strip().lower(), str(request.json['pwd']).strip()
		assert(login and pwd), 'Login e Senha são campos obrigatórios'
		assert(IsValidEmail(login)), 'Login/Email inválido'
		ipr = str(request.environ.get('HTTP_X_FORWARDED_FOR', request.remote_addr)).strip()
		assert(ipr), 'Unknown IP'
		jdata = dict({'login':login, 'pwd':pwd, 'ipr':ipr})
		jdata = dict(list(DB.Exec(f"CALL `GetAccessToken`('{dumps(jdata, ensure_ascii=False, default=str)}');"))[0][0])
		assert(len(jdata['token'])==64), 'Forbidden'
	except IndexError: return(dict(service=str(request.path[1:]), status=f'Failed: IndexError'), 500, headers_ret)
	except Exception as e: return(dict(service=str(request.path[1:]), status=f'Failed: {type(e)} {str(e)}'), 403, headers_ret)
	else: return(dict(service=str(request.path[1:]), status='OK', jdata=jdata), 200, headers_ret)
@app.route('/setContrato', methods=['POST'])
def setContrato():
	'''
		A função setContrato é utilizada para adicionar um novo contrato para um cliente específico. Ela realiza as seguintes ações:
		Verificação de autorização: A função verifica se o token enviado no cabeçalho da requisição é válido.
		Preparação dos dados: Os dados enviados na requisição são organizados em um dicionário jdata.
		Atualização do contrato: A função DB.Exec() é chamada para atualizar os dados do contrato no banco de dados.
		Remoção de informações desnecessárias: As informações não necessárias são removidas do dicionário jdata.
		Assinatura: Se o contrato for assinado (ass = 'S') e houver um identificador MP (mp_id), uma assinatura é criada na API do MercadoPago.
		Atualização do status da fatura: O status da fatura associada ao contrato é atualizado.
		Tratamento de erro: Caso algum erro ocorra, uma mensagem de erro é retornada.
		Retorno de sucesso: Se nenhum erro ocorrer, a função retorna os dados do contrato e uma mensagem de sucesso.
	'''
	try:
		assert(CheckTokenPublic())
		jdata = dict({
			'id_cliente': int(request.json['id_cliente']),
			'id_plano_mautic': int(request.json['id_plano_mautic']),
			'id_plano_smtp': int(request.json['id_plano_smtp']),
			'desc': int(request.json['desc']),
			'ass': 'S' if (request.json['ass']=='S') else 'N',
			'nfe': 'S' if (request.json['nfe']=='S') else 'N',
			'freq': int(request.json['freq']),
			'obs': request.json.get('obs',None)
		})
		jdata.update(dict(list(DB.Exec(f"CALL `SetContrato`('{dumps(jdata, ensure_ascii=False)}');"))[0][0]))
		[jdata.pop(val,None) for val in list(['obs'])]
		#:Assinatura
		if ( (int(jdata.get('id',0))==1) and (jdata.get('ass',None)=='S') and (jdata.get('mp_id',None)!=None) ):
			jmp = dict({
				'reason': jdata['nome_plano'],
				'external_reference': jdata['mp_id'],
				'payer_email': jdata['login'],
				'back_url': 'https://mktstacks.com',
				'auto_recurring': dict({'frequency':1, 'frequency_type':'months', 'currency_id':'BRL', 'transaction_amount':jdata['vlr_pagto']})
			})
			jmp=post('https://api.mercadopago.com/preapproval', timeout=10, allow_redirects=True, json=jmp, headers=headers_mpg).json()
			assert(jmp.get('id',None) is not None), 'ID MP is not set'
			sql="UPDATE `faturas` SET `status`='G', `mp_jdata`='{}' WHERE `id_cliente`='{}' AND `status`='E' AND `mp_id`='{}' ORDER BY `id` DESC LIMIT 1; COMMIT;";
			sql=f"{sql} SELECT HIGH_PRIORITY * FROM `return_msg` WHERE `id`='1';"
			jdata.update(dict(list(DB.Exec(sql.format(dumps(jmp, ensure_ascii=False), jdata['id_cliente'], jdata['mp_id'])))[0][0]))
			assert(int(jdata['id'])==1), 'Unknown'
			jdata.update(dict({'init_point':jmp['init_point']}))
	except Exception as e: return(dict(service=str(request.path[1:]), status=f'Failed: {type(e)} {str(e)}'), 500, headers_ret)
	else: return(dict(service=str(request.path[1:]), status='OK', jdata=jdata), 200, headers_ret)
@app.route('/setAccount', methods=['POST'])
def setAccount():
	#: A função setAccount é utilizada para gravar os dados cadastrais do cliente
	try:
		login, token = str(request.json['login']).strip().lower(), str(request.headers['Authorization'].split()[1]).strip()
		nome, cpf_cnpj, whatsapp = str(request.json['nome']).strip(), str(request.json['cpf_cnpj']).strip(), str(request.json['whatsapp']).strip()
		cep, cidade, uf = str(request.json['cep']).strip(), str(request.json['cidade']).strip(), str(request.json['uf']).strip()
		logradouro, numero, bairro, complemento, pais = request.json.get('logradouro',None), request.json.get('numero',None), request.json.get('bairro',None), request.json.get('complemento',None), request.json.get('pais','BR')
		email, contato = request.json.get('email',None), request.json.get('contato',None)

		whatsapp = str('55{}'.format(re.sub(r'[^\d]+', str(), whatsapp, 0, re.MULTILINE|re.IGNORECASE|re.DOTALL).strip()))
		cpf_cnpj = re.sub(r'[^\d]+', str(), cpf_cnpj, 0, re.MULTILINE|re.IGNORECASE|re.DOTALL).strip()
		cep = re.sub(r'[^\d]+', str(), cep, 0, re.MULTILINE|re.IGNORECASE|re.DOTALL).strip()
		email = email.replace(',',';') if (email) else None
		complemento = complemento.title() if (complemento) else None

		assert(login and token and nome and cpf_cnpj and whatsapp and cep and cidade and uf), 'Login, Token, Nome, CPF/CNPJ, Whatsapp, CEP, Cidade e UF são campos obrigatórios'
		assert(IsValidEmail(login)), 'Login inválido'
		assert(len(token)==64), 'Token inválido'
		assert(len(cpf_cnpj)in[11,14]), 'CPF/CNPJ inválido'
		if ( len(cpf_cnpj) == 11 ): assert(IsCPF(cpf_cnpj)), 'CPF inválido'
		if ( len(cpf_cnpj) == 14 ): assert(IsCNPJ(cpf_cnpj)), 'CNPJ inválido'
		assert(len(whatsapp)in[12,13]), 'Whatsapp inválido'
		assert(len(cep)==8), 'CEP inválido'

		jdata = dict({'login':login, 'token':token, 'nome':nome, 'cpf_cnpj':cpf_cnpj, 'whatsapp':whatsapp, 'cep':cep, 'cidade':cidade, 'uf':uf, 'logradouro':logradouro, 'numero':numero, 'bairro':bairro,
		'complemento':complemento, 'pais':pais, 'email':email, 'contato':contato})
		jdata = dict(list(DB.Exec(f"CALL `SetAccount`('{dumps(jdata, ensure_ascii=False, default=str)}');"))[0][0])
		assert(int(jdata['id']) in [1,253]), 'Unknown'
	except IndexError: return(dict(service=str(request.path[1:]), status=f'Failed: IndexError'), 500, headers_ret)
	except Exception as e: return(dict(service=str(request.path[1:]), status=f'Failed: {type(e)} {str(e)}'), 500, headers_ret)
	else: return(dict(service=str(request.path[1:]), status='OK', jdata=jdata), 200, headers_ret)
@app.route('/getAccount', methods=['POST'])
def getAccount():
	#: A função getAccount é utilizada para obter os dados cadastrais do cliente
	try:
		login, token = str(request.json['login']).strip().lower(), str(request.headers['Authorization'].split()[1]).strip()
		assert(login and token), 'Login e Token são campos obrigatórios'
		assert(IsValidEmail(login)), 'Login inválido'
		assert(len(token)==64), 'Token inválido'
		jdata = dict({'login':login, 'token':token})
		jdata = dict(list(DB.Exec(f"CALL `GetAccount`('{dumps(jdata, ensure_ascii=False, default=str)}');"))[0][0])
		assert(jdata['login'])
	except KeyError: return(dict(service=str(request.path[1:]), status=f'Failed: Forbidden'), 403, headers_ret)
	except Exception as e: return(dict(service=str(request.path[1:]), status=f'Failed: {type(e)} {str(e)}'), 500, headers_ret)
	else: return(dict(service=str(request.path[1:]), status='OK', jdata=jdata), 200, headers_ret)
@app.route('/setMercPago', methods=['POST'])
def setMercPago():
	'''
		A função setMercPago é usada para processar webhooks do MercadoPago. Ela faz as seguintes verificações/ações:
		Validação de cabeçalhos: Verifica se o cabeçalho "User-Agent" da requisição corresponde a uma expressão regular esperada.
		Validação de dados da requisição: Verifica se os valores para "type" e "action" estão definidos e se o valor para "data|id" também está definido.
		Atualização de status de pagamento: Executa uma consulta SQL para atualizar o status de pagamento para "P" (pago).
		Verificação do tipo de pagamento: Verifica se é um pagamento ou uma assinatura e executa uma requisição à API do Mercado Pago para obter informações adicionais.
		Validação de informações do pagamento: Verifica se o status é "aprovado" e se há uma referência externa e um valor de transação válido.
		Envio de notificação: Envia uma mensagem via Telegram com as informações do pagamento.
		Tratamento de exceções: Em caso de erro, retorna um dicionário com o status "Falhou" e o erro encontrado. Caso contrário, retorna um dicionário com o status "OK".
	'''
	try:
		assert(re.search(r'mercadopago.+webhook.+payment', str(request.headers.get('User-Agent')), re.MULTILINE|re.IGNORECASE|re.DOTALL)), 'User-Agent, invalid'
		assert(request.json.get('type',None) is not None), 'Type is not set'
		assert(request.json.get('action',None) is not None), 'Action is not set'
		assert(request.json.get('data',dict()).get('id',None) is not None), 'Data|Id is not set'
		with open('/root/log.txt', 'a') as f: f.write(f"{time.strftime('%c')} - {str(request.json)}\n")
		runAjustes()
		#:Pagamento
		if ( (request.json.get('type',None) == 'payment') and (request.json.get('action',None) in list(['payment.created','payment.updated'])) ):
			r=get(f"https://api.mercadopago.com/v1/payments/{request.json['data']['id']}", timeout=10, allow_redirects=True, headers=headers_mpg).json()
			with open('/root/log.txt', 'a') as f: f.write(f"{time.strftime('%c')} - {str(r)}\n")
			assert(r.get('status',None)=='approved'), 'Status is not Approved'
			assert(r.get('external_reference',None) is not None), 'External Reference is not set'
			assert(r.get('transaction_amount',0)>=5), 'Transaction Amount is not set'
			jdata = dict({'mp_id':r['external_reference'], 'vlr_pagto':r['transaction_amount']})
			jdata = dict(list(DB.Exec(f"CALL `SetBaixaFaturaMP`('{dumps(jdata, ensure_ascii=False, default=str)}');"))[0][0])
			assert(int(jdata['id']) in [1,2]), 'Unknown'
			if ( int(jdata['id']) == 1 ): SendTgm(sbj='MP Pagamento', message=f"{r.get('payer',dict()).get('email','Unknown')} - R$ {r['transaction_amount']}\n{r['external_reference']}")
		#:Assinatura
		elif ( (request.json.get('type',None) == 'subscription_authorized_payment') and (request.json.get('action',None) == 'updated') ):
			r=get(f"https://api.mercadopago.com/authorized_payments/{request.json['data']['id']}", timeout=10, allow_redirects=True, headers=headers_mpg).json()
			with open('/root/log.txt', 'a') as f: f.write(f"{time.strftime('%c')} - {str(r)}\n")
			assert(r.get('payment',dict()).get('status',None)=='approved'), 'Payment|Status is not approved'
			assert(r.get('external_reference',None) is not None), 'External Reference is not set'
			assert(r.get('transaction_amount',0)>=5), 'Transaction Amount is not set'
			jdata = dict({'mp_id':r['external_reference'], 'vlr_pagto':r['transaction_amount']})
			jdata = dict(list(DB.Exec(f"CALL `SetBaixaFaturaMP`('{dumps(jdata, ensure_ascii=False, default=str)}');"))[0][0])
			assert(int(jdata['id']) in [1,2]), 'Unknown'
			if ( int(jdata['id']) == 1 ): SendTgm(sbj='MP Assinatura', message=f"{r['reason']} - R$ {r['transaction_amount']}\n{r['external_reference']}")
		else: raise Exception('Unknown: invalid payment')
	except Exception as e: return(dict(service=str(request.path[1:]), status=f'Failed: {type(e)} {str(e)}'), 500, headers_ret)
	else: return(dict(service=str(request.path[1:]), status='OK'), 500, headers_ret)

#:MAIN
try:
	DB=Mysql()
	app.config['JSON_SORT_KEYS']=True
	app.config['JSONIFY_PRETTYPRINT_REGULAR']=True
	app.run(debug=True, host='0.0.0.0', port=443, use_reloader=True, ssl_context='adhoc')
except Exception as e: print(f'Main: {type(e)} {str(e)}')

#:END
AllClose()
sys.exit()