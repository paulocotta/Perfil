#!/usr/bin/env python3
# -*- coding: utf-8 -*-
if (True):
	#(cat '/mnt/Data/01_Dropbox/RotinasSrv/global/parallel/viacep.parallel' | (parallel -j5 {}))
	#(seq 1 30 | xargs -n1 -P10 -I\% '/mnt/Data/01_Dropbox/RotinasSrv/srv-itcloud-01/scripts/viacep-update.py')
	import sys, os; sys.dont_write_bytecode=True
	from multiprocessing import Process
	from json import dumps
	from requests import get
	# sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+'/../global/pkg')
	# from Util import CleanScreen, RunOnlyOne, SetLogging
	# from SGDB import Mysql
	headers_rest = {'Cache-Control':'no-cache', 'Pragma':'no-cache', 'User-Agent':'WhatsApp/2.20.201.2 A'}
	# CleanScreen()


print('OKKKKKK');

#:FUNCTIONS
def AllClose():
	try: sys.modules[__name__].__dict__.clear()
	except: pass
	exit()
def GetUpdateViaCep():
	try:
		records=DB.Exec('SELECT * FROM `GetUpdateViaCep` ORDER BY RAND() LIMIT 40;')
		assert(records)
		for val in records[0]:
			r=f"https://viacep.com.br/ws/{val['cep']}/json/"
			r=get(r, timeout=5, allow_redirects=True, headers=headers_rest).json()
			print(str(dumps(r, ensure_ascii=False)).replace("'", "\\'"))
			if ( r.get('localidade',None) ): DB.Exec("CALL `SetCep`(JSON_UNQUOTE('{}'));".format(str(dumps(r, ensure_ascii=False)).replace("'", "\\'")))
			else: DB.Exec(f"DELETE FROM `ceps` WHERE `ceps`.`cep`='{val['cep']}' LIMIT 1; COMMIT;")
		else: pass
	except: raise Exception('Failed: GetUpdateViaCep')

#:MAIN
AllClose() if ( RunOnlyOne(os.path.basename(__file__)) ) else SetLogging('Start')
try:
	DB=Mysql()
	GetUpdateViaCep()
	for _ in range(4): Process(target=GetUpdateViaCep).start()
except Exception as e: SetLogging(f'Main: {str(e)}', 50)

#:END
AllClose()
sys.exit()