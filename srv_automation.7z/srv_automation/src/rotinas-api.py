#!/usr/bin/env python3
# -*- coding: utf-8 -*-
if (True):
	import sys; sys.dont_write_bytecode=True
	import os, re, json
	from random import randrange, choice, shuffle
	from lxml.html import fromstring
	from subprocess import check_output
	from waitress import serve
	from requests import get
	from flask import Flask, render_template, request, jsonify, redirect, url_for
	sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+'/../global/pkg')
	from Util import CleanScreen, SendNotification, SendMailCurl, SetLogging, SendAlexa
	from SGDB import Mysql
	app = Flask(__name__)
	headers_req = {'Cache-Control':'no-cache', 'Pragma':'no-cache', 'User-Agent':'WhatsApp/2.20.201.2 A'}
	headers_ret = {'Content-Type':'application/json', 'Cache-Control':'no-cache', 'Pragma':'no-cache', 'Access-Control-Allow-Origin':'*'}
	CleanScreen()

#:FUNCTIONS
def AllClose():
	try: sys.modules[__name__].__dict__.clear()
	except: pass
	exit()
def GetGif():
	rgx, search = r'(lesbian|threesome|gay|hentai|anime|tickle|smoking|gay|double|daemon|muscle|orgy|japanese|fat|feet|foot|matures)', 'pegging'
	for _ in range(10):
		try:
			r = get(f'https://www.pornhub.com/gifs?page={randrange(1,5)}', timeout=10, allow_redirects=True, headers=headers_req)
			#r = get(f'https://pt.pornhub.com/gifs/search?search={search}&page={randrange(1,10)}', timeout=10, allow_redirects=True, stream=True, headers=headers_req)
			if ( r.status_code != 200 ): raise Exception('GIFS NOT FOUND')
			tmp = re.findall(r'<a href="(\/gif\/\d+)">$', r.text, re.MULTILINE | re.IGNORECASE)
			if ( not tmp ): continue
			shuffle(tmp)
			tmp = choice(tmp)
			r = get(f'https://www.pornhub.com{tmp}', timeout=10, allow_redirects=True, headers=headers_req)
			if ( r.status_code != 200 ): raise Exception('GIFS NOT FOUND')
			tmp = re.sub(r'[^\d]+', str(), tmp, 0, re.MULTILINE | re.IGNORECASE)
			tmp = re.findall(r'data-webm="(.+{}a.webm)"$'.format(tmp), r.text, re.MULTILINE | re.IGNORECASE)
			tmp = choice(tmp).replace('cl.phncdn.com','dl.phncdn.com').replace('el.phncdn.com','dl.phncdn.com')
			result = dict(link=tmp, fase=1, tag=None)
			tags, tmp = list(), fromstring(r.content.decode('utf-8'))
			for tag in tmp.xpath('//*[@class="tagText"]/text()'): tags.append(tag.replace('gifs',str()).strip())
			if ( not tags ): continue
			tmp = str(';'.join(tags)).strip()
			if ( re.search(rgx, tmp, re.MULTILINE | re.IGNORECASE) ): continue
			result['tag'] = tmp
			if ( re.search(r'(cum|creampie)', tmp, re.MULTILINE | re.IGNORECASE) ): result['fase'] = 2
			r = get(result['link'], timeout=10, allow_redirects=True, headers=headers_req)
			if ( r.status_code != 200 ): raise Exception('GIFS NOT FOUND')
			if ( int(r.headers['Content-Length']) > 6291456 ): raise Exception('GIFS TOP SIZE')
		except Exception as e: return('Failed', str(e))
		else: return('OK', result)
def GetBuscaPe(url=None, vmax=None):
	try:
		r = get(url, timeout=10, allow_redirects=True, headers=headers_req)
		if ( r.status_code != 200 ): raise Exception('Not Found')
		precos = re.findall(r'product-card::price.+?\$(.+?)\<', r.text, re.MULTILINE | re.IGNORECASE)
		for preco in precos:
			preco = int(float(preco.replace('.','').replace(',','.').strip()))
			if ( preco <= vmax ): return('OK', url)
	except Exception as e: return('Failed', str(e))
	return('OK', None)
def CheckToken(on=True):
	try:
		if ( not on ): return True
		tokens = list(['bf1e120eb4fff3324f6b0d4a093412e8df5ade26'])
		assert(request.headers['Authorization'].split()[1].strip() in tokens), 'Token invalid'
		return True
	except: raise
	return False

#:DEFINITIONS
@app.before_first_request
def before_first_request():
	print('Before First Request')
@app.errorhandler(404)
def page_not_found(e):
	return(dict(status=str(e)), 404, headers_ret)
@app.before_request
def before_request_func():
	print('Before request executing')
	jdata = dict(request.environ)
	try: jdata.update(dict(request.json))
	except: pass
@app.after_request
def after_request(response):
	response.headers.set('Content-Type', 'application/json')
	response.headers.set('Cache-Control', 'no-cache')
	response.headers.set('Pragma', 'no-cache')
	response.headers.set('Access-Control-Allow-Origin', '*')
	response.headers.set('Access-Control-Allow-Credentials', 'true')
	response.headers.set('Access-Control-Allow-Methods', 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT')
	response.headers.set('Access-Control-Allow-Headers', 'Content-Type,Authorization')
	return(response)

#:API
@app.route('/', methods=['GET'])
def home():
	try:
		assert(CheckToken())
		#os.system("(echo y|plink -ssh -P 2233 -pw 'Wp-0r14z' 'root@10.0.0.49' 'exit'; plink -t -batch -ssh -P 2233 -pw 'Wp-0r14z' 'root@10.0.0.49' 'timeout 1m /mnt/Data/01_Dropbox/RotinasSrv/global/scripts/rotinas-sync.sh';) >/dev/null 2>&1")
		return(redirect(r'https://google.com', code=302))
	except Exception as e: return(dict(service='home', status=f'Failed: {type(e)} - {str(e)}'), 500, headers_ret)
	else: return(dict(service='home', status='OK'), 200, headers_ret)
@app.route('/hn', methods=['POST'])
def hn():
	try:
		assert(CheckToken())
		records = DB.Exec("CALL `Ola`(JSON_OBJECT('tag','cotta'));")
		assert(records)
		cmd=list()
		[cmd.append(str(f"REG ADD '{val['path']}' /v '{val['key']}' /t {val['tipo']} /d '{val['value']}' /f").strip()) for val in records[0] if (val['action']=='C')]
	except Exception as e: return(dict(service=request.path[1:], status=f'Failed: {type(e)} - {str(e)}'), 500, headers_ret)
	else: return(dict(service=request.path[1:], status='OK', jdata=cmd), 200, headers_ret)
@app.route('/alerta', methods=['POST'])
def alerta():
	try:
		assert(CheckToken())
		texto, voice, email = str(request.json.get('texto', 'Sem Texto')), request.json.get('voice', True), request.json.get('email', False)
		quick, tgm, rpt = request.json.get('quick', False), request.json.get('tgm', True), int(request.json.get('rpt', 1))
		SendNotification(tgm=tgm, voice=voice, texto=texto, quick=quick, rpt=rpt)
		if ( email ): SendMailCurl('Notification', texto)
	except Exception as e: return(dict(service=request.path[1:], status=f'Failed: {type(e)} - {str(e)}'), 500, headers_ret)
	else: return(dict(service=request.path[1:], status='OK'), 200, headers_ret)
@app.route('/sx', methods=['GET'])
def sx():
	try:
		headers_ret.update(dict({'Refresh':300}))
		status, jdata = GetGif()
	except Exception as e: return(dict(service=request.path[1:], status=f'Failed: {type(e)} - {str(e)}'), 500, headers_ret)
	else: return(dict(service=request.path[1:], status=status, jdata=jdata), 200, headers_ret)
@app.route('/cnpj', methods=['GET'])
def cnpj():
	try:
		val=str(request.args.get('val', default=None, type=None)).strip()
		val=str(re.sub(r'[^\d]+', str(), val, 0, re.MULTILINE | re.IGNORECASE | re.DOTALL)).strip()
		assert(len(val)==14)
		r=get(f'https://brasilapi.com.br/api/cnpj/v1/{val}', timeout=10, allow_redirects=True, headers=headers_req).json()
		assert(r)
		r=dict(sorted(r.items()))
	except: return(dict(service=request.path[1:], status=f'Failed: CNPJ inválido'), 500, headers_ret)
	else: return(dict(service=request.path[1:], status='OK', jdata=r), 200, headers_ret)
@app.route('/ip', methods=['GET'])
def ip():
	try:
		ipr = str(request.environ.get('HTTP_X_FORWARDED_FOR', request.remote_addr)).strip()
		val = str(request.args.get('val', default=str(), type=None)).strip()
		val = val if ( val ) else ipr
		r=get(f'http://ip-api.com/json/{val}?fields=33292287', timeout=10, allow_redirects=True, headers=headers_req).json()
	except Exception as e: return(dict(service=request.path[1:], status=f'Failed: {type(e)} - {str(e)}'), 500, headers_ret)
	else: return(dict(service=request.path[1:], status='OK', jdata=r), 200, headers_ret)
@app.route('/status', methods=['GET'])
def status():
	try:
		url = request.args.get('url', default=None, type=None)
		assert(url), 'Url not found'
		tmp = f"curl -sfkLm10 --retry 3 --retry-delay 1 -o /dev/null -w '%{{http_code}}' '{url.strip()}'"
		tmp = f"{tmp} -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'"
		tmp = f"{tmp} -H 'Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'"
		tmp = f"{tmp} -H 'Cache-Control: no-cache' -H 'Connection: keep-alive' -H 'DNT: 1' -H 'Pragma: no-cache' -H 'Sec-Fetch-Dest: document' -H 'Sec-Fetch-Mode: navigate' -H 'Sec-Fetch-Site: none' -H 'Sec-Fetch-User: ?1'"
		tmp = f"{tmp} -H 'Upgrade-Insecure-Requests: 1' -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'"
		tmp = f"{tmp} -H 'sec-ch-ua: \"Google Chrome\";v=\"107\", \"Chromium\";v=\"107\", \"Not=A?Brand\";v=\"24\"' -H 'sec-ch-ua-mobile: ?0' -H 'sec-ch-ua-platform: \"Windows\"' --compressed"
		tmp = f"({tmp.strip()}) || true"
		tmp = int(check_output(tmp, shell=True, encoding='utf-8').strip()) or 0
	except Exception as e: return(dict(service=request.path[1:], status=f'Failed: {type(e)} - {str(e)}'), 500, headers_ret)
	else: return(dict(service=request.path[1:], status='OK', jdata=tmp), 200, headers_ret)
@app.route('/tgm', methods=['POST'])
def tgm():
	try:
		request.json['message']['text'] = str(request.json.get('message',dict()).get('text',str())).strip()
		assert(request.json['message']['text'])
		if ( re.search(r'\/alexa\s.+', str(request.json['message']['text']), re.MULTILINE | re.IGNORECASE | re.DOTALL) ):
			request.json['message']['text'] = str(re.sub(r'\/alexa\s|\s\s+', str(), request.json['message']['text'], 0, re.MULTILINE | re.IGNORECASE | re.DOTALL)).strip()
			SendAlexa(texto=request.json['message']['text'], quick=False)
	except Exception as e: return(dict(service=request.path[1:], status=f'Failed: {type(e)} - {str(e)}'), 200, headers_ret)
	else: return(dict(service=request.path[1:], status='OK'), 200, headers_ret)

#:MAIN
try:
	DB = Mysql()
	app.config['JSON_SORT_KEYS']=True
	app.config['JSONIFY_PRETTYPRINT_REGULAR'] = True
	app.run(debug=True, host='0.0.0.0', port=443, use_reloader=True, ssl_context='adhoc')
except Exception as e: SetLogging(f'Main: {type(e)} {str(e)}', 50)

#:END
AllClose()
sys.exit()

# region
'''
https://api.telegram.org/bot676689288:AAGItCflxsTv3098I7nLCwyGlWETe5J-boE/getWebhookInfo
https://api.telegram.org/bot676689288:AAGItCflxsTv3098I7nLCwyGlWETe5J-boE/setWebhook?url=https://app.wsapp.com.br/tgm
if ( __name__ == '__main__' ):
if():raise Exception('')
return str(request.get_data())
return str(request.get_data(parse_form_data=True))
return(request.args.get('tesste', default=dict(sss='sssss'), type=None))
print(request.__dict__)
return(json.dumps(records[0][0], indent=2, sort_keys=True, ensure_ascii=False, default=str))
except Exception as e: SetLog(str(e), 9)
sys.stdout = sys.stderr = open('log.txt','wt')
call("/usr/bin/python3.8 '/mnt/Data/01_Dropbox/RotinasSrv/srv-itcloud-01/scripts/rotinas-financeiro.py'", shell=True, executable='/bin/bash')
app.config['JSON_SORT_KEYS'] = True
serve(app, host='0.0.0.0', port=8443)
return(dict(status='OK'), 200, {'Access-Control-Allow-Origin':'*'})
return(redirect('https://google.com', code=302))
if ( request.method == 'POST' ): app.logger.info(request.form.get('message'))
response = jsonify(status='OK')
response.headers.set('Access-Control-Allow-Origin', '*')
response.headers.set('Access-Control-Allow-Methods', 'GET, POST')
'''
# endregion