#!/bin/bash
IMG='srv_automation';
clear; echo 'START'; sleep 1;
cd "/home/sysop/Dropbox/RotinasSrv/srv-ovh-01/${IMG}/"; sleep 1;
(docker system prune -f) >/dev/null 2>&1;
(docker rm -f $(docker ps -a | egrep -si "${IMG}" | awk '{print $1}' | xargs)) >/dev/null 2>&1;
(docker rm -f "${IMG}") >/dev/null 2>&1;
(docker stop "${IMG}") >/dev/null 2>&1;
(docker system prune -f) >/dev/null 2>&1;
(docker rmi -f "paulocotta/wsapp:${IMG}") >/dev/null 2>&1;
(docker rmi -f $(docker images --format '{{.ID}} {{.Repository}}' | egrep -si 'python|ubuntu' | awk '{print $1}' | xargs)) >/dev/null 2>&1;
(docker build --force-rm --no-cache --tag "paulocotta/wsapp:${IMG}" .);
(docker system prune -f) >/dev/null 2>&1;
(docker run -id --rm -u0 --privileged --name "${IMG}" "paulocotta/wsapp:${IMG}");
(docker images && docker ps -a);
(sleep 10 && docker exec -ti srv_automation bash);
exit 0;
#
# docker ps -a | egrep -si 'minute' | awk '{if ($8 > 30) {print $1}}'
# (docker build --force-rm --tag "paulocotta/wsapp:${IMG}" .);
# docker build --force-rm --quiet -t "paulocotta/wsapp:${IMG}" .;
# docker build --force-rm --no-cache --pull --quiet -t "paulocotta/wsapp:${IMG}" .;
# https://docs.docker.com/engine/reference/commandline/buildx_build/
# docker buildx build --platform=linux/amd64,linux/arm64 --output=type=registry -t "paulocotta/wsapp:${IMG}" .
# docker system prune -f >/dev/null 2>&1;
# docker push "paulocotta/wsapp:${IMG}";
# docker run -id --rm --privileged --log-opt max-size=100m --log-opt max-file=1000 --name "${IMG}" -p 8443:8443 -v "/home/sysop/Dropbox/RotinasSrv/":"/mnt/Data/01_Dropbox/RotinasSrv/" "paulocotta/wsapp:${IMG}";
# docker images;
# (docker images && netstat -tlnpeu);
# docker save --output "${IMG}.tar" "${IMG}";
# docker run -tid --rm --name "srv_mautic_333" "srv_mautic_333";
# docker push "paulocotta/wsapp:srv_web_01";
# docker stop $(docker ps -a -q 2>/dev/null) >/dev/null 2>&1; docker system prune -f >/dev/null 2>&1; docker ps -a;
# /mnt/Data/01_Dropbox/RotinasSrv/srv-ovh-01/docker/create.sh; /mnt/Data/01_Dropbox/MKST/scripts/mautic/create.sh;
# /home/sysop/Dropbox/RotinasSrv/srv-ovh-01/api
# sudo -H pip3 install --upgrade --force-reinstall selenium mysql-connector-python requests lxml
# docker run -tid --rm --name "${IMG}" "paulocotta/wsapp:${IMG}";
# IMG='srv_api_01';
# clear; echo 'START'; sleep 1;
# cd '/mnt/Data/01_Dropbox/RotinasSrv/srv-itcloud-02/api/'; sleep 1;
# (docker system prune -f) >/dev/null 2>&1;
# (docker rm -f $(docker ps -a 2>/dev/null | egrep -i 'srv_api_' | awk '{print $1}' | xargs)) >/dev/null 2>&1;
# (docker rm -f "${IMG}") >/dev/null 2>&1;
# (docker system prune -fa) >/dev/null 2>&1;
# (docker rmi "paulocotta/wsapp:${IMG}") >/dev/null 2>&1;
# (docker rmi $(docker images --format '{{.ID}} {{.Repository}}' | egrep -si 'python|ubuntu' | awk '{print $1}' | xargs)) >/dev/null 2>&1;
# (docker system prune -fa) >/dev/null 2>&1;
# (docker build --force-rm -t "paulocotta/wsapp:${IMG}" .);
# (docker run -id --hostname=srv_api_01 --restart=always -p 443:443 --user=root --privileged --log-opt max-size=100m --log-opt max-file=1000 --name 'srv_api_01' -v '/mnt/Data/01_Dropbox/RotinasSrv/':'/mnt/Data/01_Dropbox/RotinasSrv/' 'paulocotta/wsapp:srv_api_01');
# (clear && sleep 1);
# (docker images && netstat -tlnpeu);
# exit 0;
# netstat -tlnpeua
# (docker run -id --restart=always -p 80:80 --user=root --privileged --log-opt max-size=100m --log-opt max-file=1000 --name 'srv_api_01' -v '/mnt/Data/01_Dropbox/RotinasSrv/':'/mnt/Data/01_Dropbox/RotinasSrv/' 'paulocotta/wsapp:srv_api_01');
# (docker run -id --restart=always -p 443:80 --user=root --privileged --log-opt max-size=100m --log-opt max-file=1000 --name 'srv_api_01' -v '/mnt/Data/01_Dropbox/RotinasSrv/':'/mnt/Data/01_Dropbox/RotinasSrv/' 'paulocotta/wsapp:srv_api_01');
# docker run -id --rm --privileged --log-opt max-size=100m --log-opt max-file=1000 --name "srv_api_01" -v "/mnt/Data/01_Dropbox/RotinasSrv/":"/mnt/Data/01_Dropbox/RotinasSrv/" "paulocotta/wsapp:srv_api_01"
# docker build --force-rm --quiet -t "paulocotta/wsapp:${IMG}" .;
# docker build --force-rm --no-cache --pull --quiet -t "paulocotta/wsapp:${IMG}" .;
# https://docs.docker.com/engine/reference/commandline/buildx_build/
# docker buildx build --platform=linux/amd64,linux/arm64 --output=type=registry -t "paulocotta/wsapp:${IMG}" .
# docker push "paulocotta/wsapp:${IMG}";
# docker run -id --rm --privileged --log-opt max-size=100m --log-opt max-file=1000 --name "${IMG}" -p 8443:8443 -v "/home/sysop/Dropbox/RotinasSrv/":"/mnt/Data/01_Dropbox/RotinasSrv/" "paulocotta/wsapp:${IMG}";
# docker save --output "${IMG}.tar" "${IMG}";
# docker run -tid --rm --name "srv_mautic_333" "srv_mautic_333";
# docker push "paulocotta/wsapp:srv_web_01";
# docker stop $(docker ps -a -q 2>/dev/null) >/dev/null 2>&1; docker system prune -f >/dev/null 2>&1; docker ps -a;
# /mnt/Data/01_Dropbox/RotinasSrv/srv-ovh-01/docker/create.sh; /mnt/Data/01_Dropbox/MKST/scripts/mautic/create.sh;
# /home/sysop/Dropbox/RotinasSrv/srv-ovh-01/api
# sudo -H pip3 install --upgrade --force-reinstall selenium mysql-connector-python requests lxml
# docker run -tid --rm --name "${IMG}" "paulocotta/wsapp:${IMG}";
# chrome://flags/#allow-insecure-localhost