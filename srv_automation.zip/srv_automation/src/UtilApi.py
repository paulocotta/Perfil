#:FUNCTIONS
def AllClose():
	try: sys.modules[__name__].__dict__.clear()
	except: pass
	exit()
def SetLog(request=None):
	print('Before request executing')
	try: jdata = dict(request.environ)
	except: pass
	try: jdata.update(dict(request.json))
	except: pass
def CreateMsgMailSetCliente(login:str):
	try:
		mbody = open(r'/etc/scripts/msg/createmsgmailsetcliente.html', 'r', encoding='utf-8').read()
		mbody = re.sub(r'<!--(.|\s)*?-->', str(), mbody, 0, re.MULTILINE | re.IGNORECASE | re.DOTALL).strip()
		mbody = mbody.replace('@IDVERIFY@', str(sha256(f'@@{login}@@'.encode()).hexdigest())).strip()
		mbody = mbody.replace('@TIME@', str(time.time())).strip()
		mbody = mbody.replace('\n', str()).replace('\t', str()).strip()
	except: return(None, None)
	else: return('Marketing Stacks: Cadastro', mbody)
def CreateMsgMailSetLostPwd(jdata:dict):
	try:
		mbody = open(r'/etc/scripts/msg/createmsgmailsetlostpwd.html', 'r', encoding='utf-8').read()
		mbody = re.sub(r'<!--(.|\s)*?-->', str(), mbody, 0, re.MULTILINE | re.IGNORECASE | re.DOTALL).strip()
		mbody = mbody.replace('@LOGIN@', jdata['login']).strip()
		mbody = mbody.replace('@IDAUTH@', jdata['idauth']).strip()
		mbody = mbody.replace('@TIME@', str(time.time())).strip()
		mbody = mbody.replace('\n', str()).replace('\t', str()).strip()
	except: return(None, None)
	else: return('Marketing Stacks: Esqueci Minha Senha', mbody)
def CreateMsgMailResetPwd(): pass
def CheckTokenPublic(on=True):
	try:
		if ( not on ): return True
		token_pub = str(sha256('@{}@{}@{}@'.format(time.strftime('%d'), time.strftime('%m'), time.strftime('%y')).encode()).hexdigest())
		if ( str(request.environ.get('HTTP_X_FORWARDED_FOR', request.remote_addr)).strip() in list(['141.94.26.176']) ): return True
		assert(str(request.headers['Authorization'].split()[1]).strip()==token_pub), 'Token invalid'
		return True
	except: raise
	return False

#:DEFINITIONS
@app.before_first_request
def before_first_request():
	print('Before First Request')
@app.errorhandler(404)
def page_not_found(e):
	return(dict(status=str(e)), 404, headers_ret)
@app.before_request
def before_request():
	SetLog(request)
@app.after_request
def after_request(response):
	response.headers.set('Content-Type', 'application/json')
	response.headers.set('Cache-Control', 'no-cache')
	response.headers.set('Pragma', 'no-cache')
	response.headers.set('Access-Control-Allow-Origin', '*')
	response.headers.set('Access-Control-Allow-Credentials', 'true')
	response.headers.set('Access-Control-Allow-Methods', 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT')
	response.headers.set('Access-Control-Allow-Headers', 'Content-Type,Authorization')
	return(response)

#:DICAS
#region
'''
print(type(loads(request.get_data(as_text=True))))
print(dumps(jdata, indent=2, sort_keys=True, ensure_ascii=False, default=str))
print(request.__dict__)
if ( request.method == 'POST' ): app.logger.info(request.form.get('message'))
return(request.args.get('tesste', default=dict(sss='sssss'), type=None))
return(json.dumps(records[0][0], indent=2, sort_keys=True, ensure_ascii=False, default=str))
except Exception as e: SetLog(str(e), 9)
sys.stdout = sys.stderr = open('log.txt','wt')
serve(app, host='0.0.0.0', port=8443)
app.run(debug=True, host='0.0.0.0', port=80, use_reloader=True)
serve(app, host='0.0.0.0', port=80, url_scheme='adhoc')
app.run(debug=True, host='0.0.0.0', port=8443, use_reloader=True, ssl_context='adhoc')
em PT-BR, comente resumidamente e em tópicos a função: ""
from flask_cors import CORS
logging.getLogger('flask_cors').level = logging.DEBUG
CORS(app, support_credentials=True)
SetLog(dict({**dict(request.environ), **dict(request.json)}))
'''
#endregion