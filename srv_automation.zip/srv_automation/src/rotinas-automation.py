#!/usr/bin/python3.8
# -*- coding: utf-8 -*-
if (True):
	import sys; sys.dont_write_bytecode=True
	import os, time, re, json
	from random import randint
	from subprocess import check_output
	from requests import get
	from multiprocessing import Process
	#from selenium.webdriver.support.ui import WebDriverWait
	#from selenium.webdriver.support.color import Color
	#from selenium.webdriver.support.select import Select
	#from selenium.webdriver.chrome.service import Service as ChromeService
	from selenium import webdriver
	from selenium.webdriver.support.wait import WebDriverWait
	from selenium.webdriver.support import expected_conditions as EC
	from selenium.webdriver.common.by import By
	from selenium.webdriver.common.keys import Keys
	from selenium.common.exceptions import *
	sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+'/../global/pkg')
	from Util import CleanScreen, RunOnlyOne, SendNotification, SendTgm, SetLogging
	from SGDB import Mysql
	jdata = json.load(open('/mnt/Data/01_Dropbox/RotinasSrv/global/json/rotinas-automation.json', 'r', encoding='utf-8'))
	header = {'Content-Type':'application/json', 'Cache-Control':'no-cache', 'Pragma':'no-cache'}
	CleanScreen()

#:FUNCTIONS
def AllClose():
	try: sys.modules[__name__].__dict__.clear()
	except: pass
	exit()
def CheckIsUp(url=None):
	try:
		tmp=f"curl -sfkILm10 --retry 3 --retry-delay 3 -o /dev/null -w '%{{http_code}}' '{url}'"
		tmp=f"{tmp} -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'"
		tmp=f"{tmp} -H 'cache-control: no-cache' -H 'pragma: no-cache'"
		tmp=int(check_output(tmp.strip(), shell=True, encoding='utf-8').strip())
		assert(tmp in [200])
		return(True)
	except: return(False)
def ForceClose(container=None, driver=None):
	try: driver.quit()
	except: pass
	try:
		for app in list(['chrome', 'webpki', 'chromedriver', 'xdotool']):
			os.system(f'(docker exec -t "{container}" ""pkill -fi "{app}""") >/dev/null 2>&1')
	except: raise Exception('Failed: SeleniumStart')
def SeleniumStop(container=None):
	try: os.system(f'(docker rm -f {container}; docker system prune -f;) >/dev/null 2>&1')
	except: raise Exception('Failed: SeleniumStop')
	finally: time.sleep(1)
def SeleniumStart(container=None, debug=None):
	try:
		debug = True if ( (int(time.time())-int(os.path.getmtime(__file__))) < 2400 ) else False
		tmp='-e "TZ=America/Sao_Paulo" -e "DEBIAN_FRONTEND=noninteractive" -e "DEBCONF_NONINTERACTIVE_SEEN=true"'
		if ( debug ): tmp=f'{tmp} -e "SE_START_XVFB=false" -e "SE_VNC_NO_PASSWORD=1" -e "SE_NODE_MAX_SESSIONS=1"'
		else:
			tmp=f'{tmp} -e "SE_START_XVFB=false" -e "SE_VNC_NO_PASSWORD=1" -e "SE_NODE_MAX_SESSIONS=1" -e "SE_START_NO_VNC=false" -e "START_XVFB=false"'
			jdata['ARGS'].extend(['window-size=1920,1080', 'force-device-scale-factor=0.6', 'headless=new'])
		tmp=f'docker run -id --rm -u0 --privileged --shm-size=2g --name "{container}" {tmp} -p 4444:4444 -p 5900:5900 -p 7900:7900 "selenium/standalone-chrome:latest"'
		#tmp=f'{tmp} && sleep 3 && docker restart {container} && sleep 2'
		tmp=f'{tmp} && docker restart {container}'
		os.system(f'({tmp}) >/dev/null 2>&1')
		for _ in range(15):
			try:
				r=get('http://127.0.0.1:4444/wd/hub/status', timeout=10, allow_redirects=True, headers=header).json()
				assert(bool(r['value']['ready']))
				break
			except: time.sleep(2)
		else: raise
		SetLogging('Selenium Start')
	except: raise Exception('Failed: SeleniumStart')
def BotWhatsApp(DB=None):
	if ( not bool(jdata['BOTS']['BotWhatsApp']) ): return
	try:
		tmp=f"curl -sfkLm10 --retry 3 --retry-delay 3 'https://web.whatsapp.com/%F0%9F%8C%90/pt-br/?t={int(time.time())}'"
		tmp=f"{tmp} -H 'authority: web.whatsapp.com'"
		tmp=f"{tmp} -H 'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'"
		tmp=f"{tmp} -H 'accept-language: pt-BR,pt;q=0.9' -H 'cache-control: no-cache' -H 'dnt: 1' -H 'pragma: no-cache'"
		tmp=f"{tmp} -H 'sec-ch-ua: \"Google Chrome\";v=\"107\", \"Chromium\";v=\"107\", \"Not=A?Brand\";v=\"24\"'"
		tmp=f"{tmp} -H 'sec-ch-ua-mobile: ?0' -H 'sec-ch-ua-platform: \"Windows\"' -H 'sec-fetch-dest: document' -H 'sec-fetch-mode: navigate' -H 'sec-fetch-site: none' -H 'sec-fetch-user: ?1' -H 'upgrade-insecure-requests: 1'"
		tmp=f"{tmp} -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36' --compressed"
		tmp=check_output(tmp.strip(), shell=True, encoding='utf-8').strip()
		tmp=str().join(re.findall(r'\"(\d{1,}\.\d{1,}\.\d{1,})\"', tmp, re.MULTILINE | re.IGNORECASE | re.DOTALL)).strip()
		SetLogging(f'Version WhatsApp: {tmp}', 20)
		records = DB.Exec(f"SELECT COUNT(0) AS `count` FROM `wha_version` WHERE `versao`='{tmp}';")
		assert(records)
		if ( int(records[0][0]['count']) == 0 ):
			DB.Exec(f"INSERT INTO `wha_version` (`versao`) VALUES ('{tmp}'); COMMIT;")
			SendNotification(True, True, str(f'Nova versão WhatsApp: {tmp}'), False, 1)
	except Exception as e: SetLogging(f'BotWhatsApp: {str(e)}', 40)
def BotHelbor(options=None, DB=None, driver=None):
	if ( not bool(jdata['BOTS']['BotHelbor']) ): return
	if ( (int(time.strftime('%H')) in list([22,23,0,1,2,3,4,5,6,7])) ): return
	try:
		records = DB.Exec("SELECT COUNT(0) AS `count` FROM `despesas` WHERE `ref`=EXTRACT(YEAR_MONTH FROM NOW()) AND `status`='P' AND `tag`='helbor' AND `obs`='Condominio';")
		assert(records)
		if ( int(records[0][0]['count']) == 1 ): return
		with webdriver.Remote(command_executor='http://127.0.0.1:4444/wd/hub', options=options) as driver:
			driver.set_page_load_timeout(30); driver.set_script_timeout(30); driver.implicitly_wait(3);
			driver.get('https://hubert-app-boletoexpresso.azurewebsites.net')
			for _ in range(3): driver.delete_all_cookies(); time.sleep(0.5);
			WDWait = WebDriverWait(driver, timeout=15, poll_frequency=2, ignored_exceptions=[NoSuchElementException,ElementNotVisibleException,ElementNotSelectableException])
			WDWait.until(EC.title_contains('Segunda Via de Boleto'))
			WDWait.until(EC.visibility_of_element_located((By.XPATH,'//*[@id="optCPF"]'))).click()
			WDWait.until(EC.visibility_of_element_located((By.XPATH,'//*[@id="txtCpfCnpj"]'))).click()
			driver.execute_script('document.querySelector("#txtCpfCnpj").value="04974973606"')
			WDWait.until(EC.visibility_of_element_located((By.XPATH,'//*[@id="cmdContinuarCPF"]'))).send_keys(Keys.ENTER)
			try: WDWait.until(EC.visibility_of_element_located((By.XPATH, '//*[@id="lblMsgSemBoleto1"]')))
			except: SendNotification(True, True, 'Boleto Hélbor disponível', False, 1)
	except Exception as e: SetLogging(f'BotHelbor: {str(e)}', 40)
	finally: ForceClose('srv-selenium', driver)
def BotInterativa(options=None, driver=None):
	if ( not bool(jdata['BOTS']['BotInterativa']) ): return
	# if ( (int(time.strftime('%H')) in list([22,23,0,1,2,3,4,5,6,7])) ): return
	try:
		records = DB.Exec("SELECT COUNT(0) AS `count` FROM `despesas` WHERE `ref`=EXTRACT(YEAR_MONTH FROM NOW()) AND `status`='P' AND `tag`='itcloud' AND `obs`='DAS';")
		assert(records)
		if ( int(records[0][0]['count']) == 1 ): return
		with webdriver.Remote(command_executor='http://127.0.0.1:4444/wd/hub', options=options) as driver:
			driver.set_page_load_timeout(30); driver.set_script_timeout(30); driver.implicitly_wait(3);
			driver.get('https://econtador.alterdata.com.br/INTERATIVA')
			WDWait = WebDriverWait(driver, timeout=15, poll_frequency=2, ignored_exceptions=[NoSuchElementException,ElementNotVisibleException,ElementNotSelectableException])
			WDWait.until(EC.title_contains('eContador'))
			WDWait.until(EC.visibility_of_element_located((By.XPATH, '//*[@id="CpfCNPJUsuario"]'))).send_keys('04974973606')
			WDWait.until(EC.visibility_of_element_located((By.XPATH, '//*[@id="Senha"]'))).send_keys('Wp-0r14z',Keys.ENTER)
			try: WDWait.until(EC.visibility_of_element_located((By.XPATH, '//*[@id="dashboard-container"]/div/div[2]/div[1]/div[2]/div/p')))
			except: SendNotification(True, True, 'Boleto Interativa disponível', False, 1)
	except Exception as e: SetLogging(f'BotInterativa: {str(e)}', 40)
	finally: ForceClose('srv-selenium', driver)
def BotSOP(options=None, driver=None) -> None:
	#region
	'''
	BotSOP: Ranking Google
	:param options: Options, defaults to None
	:raises None: Failed: BotSOP
	:return: None
	'''
	#endregion
	if ( not bool(jdata['BOTS']['BotSOP']) ): return
	if ( (int(time.strftime('%H')) not in list([23,0,1,2,3,4,5,6,7])) ): return
	try:
		with webdriver.Remote(command_executor='http://127.0.0.1:4444/wd/hub', options=options) as driver:
			driver.set_page_load_timeout(30); driver.set_script_timeout(30); driver.implicitly_wait(3);
			for _ in range(randint(5,15)):
				driver.get(f'https://google.com.br/?t={int(time.time())}')
				for _ in range(3): driver.delete_all_cookies(); time.sleep(0.5);
				WDWait = WebDriverWait(driver, timeout=15, poll_frequency=2, ignored_exceptions=[NoSuchElementException,ElementNotVisibleException,ElementNotSelectableException])
				WDWait.until(EC.title_contains('Google'))
				WDWait.until(EC.visibility_of_element_located((By.XPATH,'//*[@aria-label="Pesquisar"]'))).send_keys('jogo+erotico+punicao',Keys.ENTER); time.sleep(randint(1,5));
				for _ in range(10):
					try: WDWait.until(EC.element_to_be_clickable((By.XPATH,'//*[contains(@href, "sexooupunicao.com")]'))).click()
					except:
						try: WDWait.until(EC.element_to_be_clickable((By.XPATH,'//*[@id="pnnext"]/span[1]'))).click()
						except: break
					else:
						time.sleep(randint(1,5))
						WDWait.until(EC.element_to_be_clickable((By.XPATH,'//button[contains(text(),"18 ANOS")]'))).click()
						WDWait.until(EC.element_to_be_clickable((By.XPATH,'//input[@id="nome_m"]'))).send_keys('Paulo'); time.sleep(randint(1,5));
						WDWait.until(EC.element_to_be_clickable((By.XPATH,'//input[@id="nome_f"]'))).send_keys('Michelle'); time.sleep(randint(1,5));
						break
				else: raise
				driver.save_screenshot('/tmp/sop.png')
			else: pass
	except Exception as e: SetLogging(f'BotSOP: {type(e)} {str(e)}', 40)
	finally: ForceClose('srv-selenium', driver)
def BotRezende(options=None, data='2023-11-13', driver=None):
	if ( not bool(jdata['BOTS']['BotRezende']) ): return
	if ( (int(time.strftime('%H')) not in list([7,8,10,12,14,15,16,18,20,22])) ): return
	if ( not CheckIsUp('https://ais.usvisa-info.com/pt-br/niv/users/sign_in') ): return
	try:
		dt1 = time.strptime(data, '%Y-%m-%d')
		with webdriver.Remote(command_executor='http://127.0.0.1:4444/wd/hub', options=options) as driver:
			driver.set_page_load_timeout(30); driver.set_script_timeout(30); driver.implicitly_wait(3);
			driver.get('https://ais.usvisa-info.com/pt-br/niv/users/sign_in'); driver.refresh();
			for _ in range(3): driver.delete_all_cookies(); time.sleep(0.5);
			for _ in range(20):
				try:
					WDWait = WebDriverWait(driver, timeout=15, poll_frequency=2, ignored_exceptions=[NoSuchElementException,ElementNotVisibleException,ElementNotSelectableException])
					WDWait.until(EC.title_contains('Department of State Visa Appointment Service'))
					WDWait.until(EC.visibility_of_element_located((By.XPATH,'//*[@id="user_email"]'))).send_keys('paulosdr@yahoo.com.br')
					WDWait.until(EC.visibility_of_element_located((By.XPATH,'//*[@id="user_password"]'))).send_keys('V1st0#2022')
					driver.execute_script('document.querySelector("#policy_confirmed").click()')
					WDWait.until(EC.visibility_of_element_located((By.XPATH,'//input[@name="commit"]'))).click()
					WDWait.until(EC.visibility_of_element_located((By.XPATH,'//td[(contains(text(), "PAULO SERGIO DUTRA DE REZENDE"))]')))
					driver.get('https://ais.usvisa-info.com/pt-br/niv/schedule/44452905/appointment/days/55.json')
					tmp = str(WDWait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/pre'))).text).strip(); print(tmp);
					tmp = json.loads(tmp)
					SendNotification(True, True, 'Automação visto', False, 1) if ( tmp ) else SendNotification(True, True, 'Automação visto falhou', False, 1)
					for v in tmp:
						if ( time.strptime(v['date'], '%Y-%m-%d') < dt1 ):
							SendTgm(message=f'''Data disponível (Visto): {v['date']}''', target='5782081138')
							SendTgm(message=f'''Data disponível (Visto): {v['date']}''', target='201591376')
							print(f'''Data disponível (Visto): {v['date']}''')
				except Exception as e: SetLogging(str(e), 40)
				else: break
			else: SendNotification(True, True, 'Sistema visto indisponível', False, 1)
	except Exception as e: SetLogging(f'BotRezende: {str(e)}', 40)
	finally: ForceClose('srv-selenium', driver)
def BotClaro(options=None, dias=2, driver=None):
	if ( not bool(jdata['BOTS']['BotClaro']) ): return
	if ( (int(time.strftime('%H')) not in list([8,10,12,14,16,18,20])) ): return
	try:
		tmp=check_output(r"/usr/bin/b2 ls --recursive --long 'pectore'|egrep -si 'fatclaro'|awk '{print $3}'", shell=True, encoding='utf-8').strip()
		tmp=re.sub(r'[^\d]+', str(), tmp, 0, re.MULTILINE|re.IGNORECASE|re.DOTALL).strip()
		tmp=tmp if ( tmp ) else 0
		if ( (int(time.strftime('%Y%m%d')) - int(tmp)) < dias ): return
		os.system(r"(rm -rf '/tmp/fatclaro.png') >/dev/null 2>&1")
		with webdriver.Remote(command_executor='http://127.0.0.1:4444/wd/hub', options=options) as driver:
			driver.set_page_load_timeout(30); driver.set_script_timeout(30); driver.implicitly_wait(3);
			driver.get(f'https://minhaclaroresidencial.claro.com.br/?t={int(time.time())}')
			for _ in range(3): driver.delete_all_cookies(); time.sleep(0.5);
			WDWait = WebDriverWait(driver, timeout=15, poll_frequency=3, ignored_exceptions=[NoSuchElementException,ElementNotVisibleException,ElementNotSelectableException])
			WDWait.until(EC.title_contains('Minha Claro'))
			WDWait.until(EC.visibility_of_element_located((By.XPATH,'//a[contains(text(),"Entrar")]'))).send_keys(Keys.ENTER)
			WDWait.until(EC.visibility_of_element_located((By.XPATH,'//input[@name="Login"]|//input[@id="mdn-MainContent"]|//input[contains(@title,"EmailUser")]'))).send_keys('cotta.paulo@gmail.com',Keys.ENTER)
			WDWait.until(EC.visibility_of_element_located((By.XPATH,'//*[@id="password"]'))).send_keys('Wp-0r14z',Keys.ENTER)
			WDWait.until(EC.visibility_of_element_located((By.XPATH,'//button[contains(text(),"Salvar")]'))).send_keys(Keys.ENTER)
			WDWait.until(EC.visibility_of_element_located((By.XPATH,'//button[contains(text(),"Fechar")]'))).send_keys(Keys.ENTER)
			try: WDWait.until(EC.presence_of_element_located((By.XPATH,'/html/body/main/div[1]/section/div[1]/div[4]/div/button'))).send_keys(Keys.ENTER)
			except: pass
			finally: time.sleep(1)
			WDWait.until(EC.presence_of_element_located((By.XPATH,'//*[@id="invoiceAmount"]'))); time.sleep(5);
			WDWait.until(EC.presence_of_element_located((By.XPATH,'(//*[@class="card"])[2]'))).screenshot('/tmp/fatclaro.png')
		assert os.path.isfile('/tmp/fatclaro.png')
		os.system(r"(('/usr/bin/b2' upload-file --noProgress --threads=10 --quiet 'pectore' '/tmp/fatclaro.png' 'fatclaro.png') && (sleep 5)) >/dev/null 2>&1")
		SendTgm(message='Fatura Internet Claro', file_url='https://pectore.s3.us-west-000.backblazeb2.com/fatclaro.png')
	except Exception as e: SetLogging(f'BotClaro: {str(e)}', 40)
	finally: ForceClose('srv-selenium', driver)
def BotAluguel(options=None, valor=3000, driver=None):
	if ( not bool(jdata['BOTS']['BotAluguel']) ): return
	if ( (int(time.strftime('%H')) in list([23,0,1,2,3,4,5,6,7])) ): return
	for _ in range(3):
		try:
			with webdriver.Remote(command_executor='http://127.0.0.1:4444/wd/hub', options=options) as driver:
				driver.set_page_load_timeout(30); driver.set_script_timeout(30); driver.implicitly_wait(3);
				url=f'https://www.vivareal.com.br/aluguel/sp/cabreuva/#preco-ate={valor}&tipos=casa_residencial,condominio_residencial,sobrado_residencial&t={int(time.time())}'
				driver.get(url); print(url);
				for _ in range(3): driver.delete_all_cookies(); time.sleep(0.5);
				WDWait = WebDriverWait(driver, timeout=15, poll_frequency=2, ignored_exceptions=[NoSuchElementException,ElementNotVisibleException,ElementNotSelectableException])
				WDWait.until(EC.title_contains('Cabreúva')); time.sleep(3);
				e=WDWait.until(EC.visibility_of_all_elements_located((By.XPATH,'//*[@data-type="property"]')))
				driver.save_screenshot('/tmp/aluguel.png')
				if ( len(e) != 2 ): SendNotification(True, True, 'Aluguel Cabreúva', False, 1)
		except Exception as e: SetLogging(f'BotAluguel: {type(e)} {str(e)}', 40)
		finally: ForceClose('srv-selenium', driver)
		time.sleep(30)
	else: pass
def BotRacao(options=None, valor=250, driver=None):
	if ( not bool(jdata['BOTS']['BotRacao']) ): return
	if ( (int(time.strftime('%H')) in list([23,0,1,2,3,4,5,6,7])) ): return
	r=str(get('https://www.casadoprodutor.com.br/7891000037492-rac-o-pro-plan-reduced-calorie-c-es-adultos-racas-medias-e-grandes-15-kg.html', timeout=10, allow_redirects=True, headers=header).text).strip()
	r=str().join(re.findall(r'\"product:price:amount\".content=\"(.+)\"', r, re.MULTILINE | re.IGNORECASE)).strip()
	if ( float(r) <= valor ): SendNotification(True, True, 'Ração com preço baixo', False, 1)

#:MAIN
AllClose() if ( RunOnlyOne(os.path.basename(__file__)) ) else SetLogging('Start')
try:
	DB=Mysql()
	SeleniumStop('srv-selenium')
	SeleniumStart('srv-selenium')
	jdata['ARGS'].extend(['window-size=1920,1080', 'force-device-scale-factor=0.6'])
	options=webdriver.ChromeOptions()
	for arg in list(set(jdata['ARGS'])): options.add_argument(arg)
	#:Se você quiser que o Chrome e o chromedriver permaneçam abertos depois, você pode adicionar a opção de "detach" ao iniciar o chromedriver
	options.add_experimental_option('detach', False)
	options.add_experimental_option('excludeSwitches', ['enable-automation','enable-logging'])
	options.add_experimental_option('useAutomationExtension', False)
	options.add_experimental_option('prefs', jdata['PREFS'])
	options.set_capability('javascriptEnabled', True)
	options.set_capability('browserName', 'chrome')
	#:INIT
	Process(target=BotWhatsApp, args=(DB,)).start()
	BotHelbor(options, DB)
	BotSOP(options)
	BotInterativa(options)
	BotClaro(options)
	BotAluguel(options)
	BotRacao(options)
	ForceClose('srv-selenium', None)
except Exception as e: SetLogging(f'Main: {type(e)} {str(e)}',50)
finally: SeleniumStop('srv-selenium')

#:END
AllClose()
sys.exit()

# region
'''
	https://www.vivareal.com.br/aluguel/sp/cabreuva/#preco-ate=2600&tipos=casa_residencial,condominio_residencial&t=244
	https://support.smartbear.com/crossbrowsertesting/docs/automated-testing/automation-capabilities.html
	driver = webdriver.Remote(command_executor='http://127.0.0.1:{}/wd/hub'.format(jdata['SETS']['container_port']), desired_capabilities=DesiredCapabilities.CHROME, options=options)
	https://www.vivareal.com.br/aluguel/sp/cabreuva/#preco-ate=2600&tipos=casa_residencial,condominio_residencial
	tmp=f'docker run -id --rm -u0 --privileged --shm-size=2g --name "{container}" {tmp} -p 4444:4444 -p 5900:5900 -p 7900:7900 "selenium/standalone-chrome:109.0"'
	https://www.selenium.dev/blog/2023/headless-is-going-away/
	tmp = '--no-healthcheck -e "TZ=America/Sao_Paulo" -e "DEBIAN_FRONTEND=noninteractive" -e "DEBCONF_NONINTERACTIVE_SEEN=true"'
	tmp = f'{tmp} -e "SE_START_NO_VNC=false" -e "SE_START_XVFB=false" -e "SE_VNC_NO_PASSWORD=1" -e "SE_NODE_MAX_SESSIONS=1" -e "SE_JAVA_OPTS=-Xmx1024m"'
	--log-opt max-size=100m --log-opt max-file=1000
	curl -sfkLm10 --retry 5 --retry-delay 5 'http://10.8.0.17/sitio';
	setInterval(function(){document.querySelector("#noVNC_connect_button").click()},10000);
	Monitoring - Alerts - CORP | SRE & DEVOPS <871f1b3a.falconi365.onmicrosoft.com@amer.teams.ms>
	integracoessistemas@falconi.com;Qz7ZR6PN
	if ( debug ): os.system(f'(docker exec -t "{container}" ""/usr/bin/fbsetroot -solid black"")')
'''
# endregion