#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# tmp = 'fping -q -C20 -t{} {};'.format(2000, HOSTS_ICMP); print(tmp);
# tmp = subprocess.run(tmp, shell=True, check=False, capture_output=True, encoding='utf-8')
if (True):
	import sys; sys.dont_write_bytecode=True
	import os, json
	from random import sample
	from subprocess import check_output
	sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+'/../global/pkg')
	from Util import CleanScreen, SetLogging, RunOnlyOne, SendNotification
	jdata = json.load(open('/mnt/Data/01_Dropbox/RotinasSrv/global/json/nping.json', 'r', encoding='utf-8'))
	CleanScreen()
	if ( int(check_output("apt list --installed 2>/dev/null | egrep -i 'nmap' | egrep -i 'installed' | wc -l", shell=True).decode('utf-8').strip()) <= 0 ): print('Install Nmap'); exit();

#:FUNCTIONS
def AllClose():
	try: sys.modules[__name__].__dict__.clear()
	except: pass
	exit()

#:MAIN
AllClose() if ( RunOnlyOne(os.path.basename(__file__)) ) else SetLogging('Start')
os.system(f'(renice -n -5 {os.getpid()}) >/dev/null 2>&1;')
try:
	for val in sample(jdata, len(jdata)):

		if ( not val['ativo'] ): continue

		print(val['host'], val['desc'])
		if ( val['port'] == 0 ):
			r = int(check_output(f'''nping -q {val['host']} | egrep -i 'lost' | awk -F: {{'print $4'}} | xargs | awk {{'print $1'}} | xargs''', shell=True).decode('utf-8').strip())
		else:
			r = int(check_output(f'''nping -q --tcp-connect -p {val['port']} {val['host']} | egrep -i 'failed' | awk -F: {{'print $4'}} | xargs | awk {{'print $1'}} | xargs''', shell=True).decode('utf-8').strip())
		if ( r >= 4 ): SendNotification(True, True, str(f'''{val['desc']} is down'''), True, 1)
except Exception as e: SetLogging(f'Main: {str(e)}', 50)

#:END
AllClose()
sys.exit()