#!/usr/bin/python3.8
# -*- coding: utf-8 -*-
if (True):
	import sys; sys.dont_write_bytecode=True
	import os, logging, re, time, socket, imaplib, smtplib, json, mimetypes
	from base64 import b64decode
	from urllib3 import disable_warnings
	from configparser import ConfigParser
	from shutil import disk_usage
	from datetime import datetime, timedelta
	from subprocess import check_output
	from ssl import create_default_context
	from inspect import currentframe
	from urllib import parse
	from hashlib import sha1
	from random import randint, randrange
	from email import encoders
	from email.utils import formatdate
	from email.mime.multipart import MIMEMultipart
	from email.mime.text import MIMEText
	from email.mime.base import MIMEBase
	from requests import get, post
	RED, GREEN, YELLOW, BLUE, RSTCOR = '\033[0;31m', '\033[0;32m', '\033[0;33m', '\033[0;34m', '\033[0m'
	logging.basicConfig(level=20, force=True, filename='/tmp/logging.log', filemode='a', format=f'%(asctime)s - %(levelname)s - %(message)s - %(funcName)s - %(lineno)d - {str(os.path.basename(sys.argv[0].strip()))} - %(filename)s')
	#logging.basicConfig(level=20, force=True, filename='/tmp/logging.log', filemode='a', format=f'{str(os.uname()[1].lower().strip())} - %(asctime)s - %(levelname)s - %(message)s - %(funcName)s - %(lineno)d - {str(os.path.basename(sys.argv[0].strip()))} - %(filename)s')
	token_wswha, token_tgm, key_uptimerobot = '219eae5aa550ac56140122b7f85f5d254b29c513', '676689288:AAGItCflxsTv3098I7nLCwyGlWETe5J-boE', 'u63230-7f555443dd9a36f20bd7a1b8'
	headers_rest = {'Cache-Control':'no-cache', 'Pragma':'no-cache', 'User-Agent':'WhatsApp/2.20.201.2 A'}
	headers_json = {'Cache-Control':'no-cache', 'Pragma':'no-cache', 'User-Agent':'WSAPP - Util (SendWha)', 'Accept':'application/json', 'Content-Type':'application/json'}
	curl = 'curl -sfkLm10 -H "Cache-Control: no-cache" -H "Pragma: no-cache" -H "User-Agent: WSWHA - https://wsapp.com.br" "{}"'
	#curl = 'curl -sfkLm10 --tcp-nodelay -H "Cache-Control: no-cache" -H "Pragma: no-cache" -H "User-Agent: WSWHA - https://wsapp.com.br" "{}"'

#: CLEANSCREEN - Limpa tela
def CleanScreen():
	if ( os.name == 'posix' ): os.system('clear;')

#: SEND MACRODROID - Envia Macrodroid
def SendMacrodroid(texto=None, vol=80, rpt=1):
	try:
		uids = set(['0359b789-06b1-4e61-91a6-c60762434fe6','647952c7-c1a9-48ff-8875-2041076cbb27'])
		for uid in uids:
			for _ in range(rpt):
				for _ in range(5):
					try:
						r=get(f'https://trigger.macrodroid.com/{uid}/talkme?text={parse.quote(texto)}&volume={vol}', timeout=10, allow_redirects=True, headers=headers_rest)
						if ( not (int(r.status_code) in list([200])) ): raise
					except: pass
					else: break
				if ( rpt > 1 ): time.sleep(len(texto)/4)
	except: print('Failed: SendMacrodroid')

#: SEND ALEXA - Envia Alexa
def SendAlexa(texto=None, quick=False, rpt=1):
	try:
		access_token, secret_token = 'd58d47cd002fc8ddd0bf380e47400383', 'd1adc2bd8107f56ffbca0a8c3957f154'
		url = f'https://api.voicemonkey.io/trigger?access_token={access_token}&secret_token={secret_token}&monkey=wsapp&announcement={texto}'
		if ( quick ): url = f"https://api.voicemonkey.io/trigger?access_token={access_token}&secret_token={secret_token}&monkey=wsapp&announcement=<prosody rate='x-fast'>{texto}</prosody>"
		for _ in range(rpt):
			for _ in range(5):
				try:
					r=get(url, timeout=10, allow_redirects=True, headers=headers_rest)
					assert(r.status_code==200)
					break
				except: pass
			else: raise
			if ( rpt > 1 ): time.sleep(len(texto)/4)
	except: print('Failed: SendAlexa')

#: SEND TELEGRAM - Envia uma notificacao por Telegram via POST/JSON : Michelle (197434107)
#https://api.telegram.org/bot676689288:AAGItCflxsTv3098I7nLCwyGlWETe5J-boE/getUpdates
def SendTgm(sbj=None, message=None, file_url=None, target=None, token=None):
	try:
		files, sbj = None, str(sbj).strip() if ( sbj ) else None
		message = str(message).strip() if ( message ) else None
		file_url = str(file_url).strip() if ( file_url ) else None
		target = str(target).strip() if ( target ) else '201591376'
		token = str(token).strip() if ( token ) else '676689288:AAGItCflxsTv3098I7nLCwyGlWETe5J-boE'
		message = f'<b>{sbj}</b>\n{message}'.strip() if ( sbj ) else message
		if ( file_url ):
			method = 'sendPhoto'
			if ( 'http' in file_url ): payload = {'chat_id':target, 'photo':file_url, 'caption':message.replace('_','\_'), 'parse_mode':'html'}
			else: payload, files = {'chat_id':target, 'caption':message.replace('_','\_'), 'parse_mode':'html'}, {'photo':open(file_url, 'rb').read()}
		else: method, payload = 'sendMessage', {'chat_id':target, 'text':message.replace('_','\_'), 'parse_mode':'html'}
		for _ in range(5):
			try:
				r=post(f'https://api.telegram.org/bot{token}/{method}', timeout=10, allow_redirects=True, data=payload, files=files, headers=headers_rest)
				if ( not (int(r.status_code) in list([200])) ): raise
			except: pass
			else: break
		else: raise
	except: print('Failed: SendTgm')

#: SEND NOTIFICATION - Envia notificacao
def SendNotification(tgm=True, voice=True, texto=None, quick=False, rpt=1):
	try:
		if ( (int(time.strftime('%H')) in list([3,4,5,6])) ): return True
		from multiprocessing import Process
		if ( (texto == None) or (len(texto.strip()) == 0) ): texto=str('Sem Texto')
		rpt, texto = int(rpt), texto.replace('SITIO','SÍTIO').replace('*','').replace('🌧️','').strip()
		#:Alexa
		if ( voice ): Process(target=SendAlexa, args=(texto,quick,rpt,)).start()
		#:Telegram
		if ( tgm ): Process(target=SendTgm, args=(None,texto,None,None,None,)).start()
	except: raise Exception('Failed: SendNotification')
	else: return True
	return False

#: SEND SMS - Envia uma notificacao por SMS
def SendSms(message=None, target='5511946034552', flashsms=False):
	try:
		querystring = {'napikey':'QUtJVW0wNlVZUlliWTloZEU2YkdJZzY1N01hRUJGZ0Q='}
		payload = {'numberPhone':target, 'message':message, 'flashSms':flashsms}
		post('https://api.nvoip.com.br/v2/sms', timeout=10, allow_redirects=True, json=payload, headers=headers_json, params=querystring)
	except: return False
	return True

#: SEND WHA - Envia uma notificacao por Whatsapp via POST/JSON
def SendWha(message=None, target='5511946034552', file_url=None, debug=False):
	try:
		target, message = str(target).strip() if target else None, message.strip() if message else None
		message = RemoveTags(message)
		payload = {'token':token_wswha, 'target':target, 'message':message, 'file_url':file_url, 'delay':5}
		for _ in range(5):
			try:
				r=post('https://api.wsapp.com.br/sendWhaMsg.php', timeout=10, allow_redirects=True, json=payload, headers=headers_json)
				if ( not (int(r.status_code) in list([200])) ): raise
			except: pass
			else: break
		else: raise
	except: debug, message = True, 'ERROR: SendWha'
	else: message = f'{target} - {message}'
	if ( debug ): SetLog(message)
	return True

#: IS PING - Check Ping (ping)
def IsPing(host='8.8.8.8', count=1, debug=True, wait=0):
	if ( os.system('ping -q -c{} -i0.1 -W1 {} >/dev/null 2>&1;'.format(count, host)) == 0 ): return True
	if ( debug ): SetLog('NOT PING: {}'.format(host),1)
	time.sleep(wait)
	return False

#: IS FPING - Check Ping (fping)
def IsFping(host='8.8.8.8', wait=2, timeout=1000, debug=True, rand=False):
	if ( (rand) and (randrange(15) != 5) ): return True
	if ( os.system(f'fping -t{timeout} {host} >/dev/null 2>&1;') == 0 ): return True
	if ( debug ): SetLog(f'Ping Error: {host}', 1)
	time.sleep(wait)
	return False

#: CHECK CERTIFICATE - Verifica o certificado
def CheckCertificate(host='wsapp.com.br'):
	send, msg = False, 'Problema em obter as informações do certificado.\n{}'.format(host.upper())
	try:
		r=check_output(f'''curl -sfkLm10 --retry 3 --retry-delay 3 --tcp-nodelay -vvI "https://{host}" 2>&1 | egrep "expire date" | cut -d":" -f2- | xargs''', shell=True, encoding='utf-8').strip()
		r=datetime.strptime(r, '%b %d %H:%M:%S %Y %Z')
	except: send = True
	else: send = True if (datetime.now() > (r - timedelta(days=7))) else False
	if ( send ): SendTgm(sbj='Certificado WSAPP', message=msg)

#: SITIO IS MANUAL - Verifica se Auto/Manual
def SitioIsManual(route='192.168.1.1'):
	tmp = f'sshpass -p "Wp-0r14z" ssh -oStrictHostKeyChecking=no root@{route} "cat /proc/net/arp" 2>/dev/null'
	tmp = f'{tmp} | grep -Ei "00:0a:f5:64:a5:68|80:ad:16:46:88:d3|f0:d7:aa:b3:ee:47|a8:96:75:47:85:f3|be:d9:91:a9:65:52" | wc -l;'
	try: tmp=int(str(check_output(tmp, shell=True, encoding='utf-8')).strip())
	except: tmp=0
	return bool(tmp)

#: INTERNET LENTA - Verifica se a internet esta lenda. Envia uma notificacao de audio
def InternetLenta(dmin=7, umin=0.5, pmin=100):
	try: tmp = json.loads(check_output('/usr/bin/python3.8 /usr/local/bin/speedtest.py --json', shell=True, encoding='utf-8').strip())
	except: pass
	else:
		print(tmp)
		if ( ((float(tmp['download'])/1024/1024) > dmin) and ((float(tmp['upload'])/1024/1024) > umin) and (float(tmp['ping']) < pmin) ): return False
	SendNotification(True, True, 'Atenção! Internet lenta!', False, 1)
	return False

#: GET UPTIMEROBOT - Obtem Status dos Monitores
def GetUptimeRobot(id='785861063'):
	payload = {'api_key':key_uptimerobot, 'monitors':id, 'format':'json'}
	try:
		tmp = post('https://api.uptimerobot.com/v2/getMonitors', timeout=10, allow_redirects=True, json=payload, headers=headers_json).json()
		return int(tmp['monitors'][0]['status'])
	except: return 9

#: GET News Google - Obtem ultimas noticias do Google
def GetNewsGoogle():
	try:
		tmp = get('https://newsapi.org/v2/top-headlines?sources=google-news-br&apiKey={}'.format('f0b87e2aaf71497ca29449887af3268f'), timeout=10, allow_redirects=True, headers=headers_rest).json()
		return str(tmp['articles'][randrange(len(tmp['articles']))]['title']).strip()
	except: pass
	return str()

#: SET UPTIMEROBOT - Start/Stop dos Monitores
def SetUptimeRobot(status=None):
	payload = {'api_key':key_uptimerobot, 'format':'json'}
	try:
		tmp = post('https://api.uptimerobot.com/v2/getMonitors', timeout=10, allow_redirects=True, json=payload, headers=headers_json)
		for val in tmp.json()['monitors']:
			payload = {'api_key':key_uptimerobot, 'id':val['id'], 'status':status, 'format':'json'}
			post('https://api.uptimerobot.com/v2/editMonitor', timeout=10, allow_redirects=True, data=payload, headers=headers_rest)
			time.sleep(7)
	except: pass

#: GET SIZE DISK - Obtem espaco livre no HD
def GetSizeDisk():
	total, used, free = disk_usage('/')
	return((total // (2**30)), (used // (2**30)), (free // (2**30)))

#: GET HOSTNAME - Obtem hostname
def GetHostName():
	return(socket.gethostname().lower())

#: GET BATTERY LEVEL - Obtem informacoes da bateria
def GetBatteryLevel(percent=50):
	try: percent = str(check_output("upower -i /org/freedesktop/UPower/devices/battery_BAT0 | grep 'percentage:' | awk '{{print $2}}' | xargs", shell=True, encoding='utf-8')).strip()
	except: pass
	else:
		try: percent = int(percent.replace('%',''))
		except: percent = 71
	SetLog('BATERIA: {}'.format(percent))
	return percent

#: GET TEMPERATURE RPI - Obtem temperatura do RaspberryPI
def GetTemperatureRPi(temp=0):
	try: temp = check_output("/usr/bin/vcgencmd measure_temp | grep -o '[0-9]*\.[0-9]*' | xargs", shell=True, encoding='utf-8').strip()
	except: pass
	return float(temp.strip())

#: IS PORT OK - Check Port
def IsPortOK(host=None, port=None):
	sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	sock.settimeout(5)
	try: result = sock.connect_ex((host, int(port)))
	except: pass
	else: return True if ( result == 0 ) else False
	return False

#: GET SAUDACAO - Gera saudacoes
def GetSaudacao():
	hora = int(datetime.now().strftime('%H'))
	if ( hora < 6 ): return 'Boa Madrugada'
	elif ( hora < 12 ): return 'Bom Dia'
	elif ( hora < 18 ): return 'Boa Tarde'
	elif ( hora < 24 ): return 'Boa Noite'

#: GET NUM EMAILS - Conecta no email e obtem o numero de emails nao lidos
def GetNumEmails(usr=None, pwd=None, tipo=None):
	try:
		imap = imaplib.IMAP4_SSL('imap.gmail.com', 993)
		imap.login(usr, pwd)
		imap.select('INBOX')
		status, data = imap.search(None, tipo)
	except: SetLog('Error GetNumEmails')
	else:
		if ( status == 'OK' ):
			imap.close()
			imap.logout()
			return len(data[0].decode('utf-8').strip().split())
	return 0

#: GET CPF - Consulta CPF Rede Pitagoras, GET/JSON
def GetCPF(cpf=None, ret=False):
	key = sha1(datetime.now().strftime('%d%m%Y').encode('utf-8')).hexdigest()
	try:
		tmp = get('https://redepitagoras.com.br/class/class.educamais.php?key={}&cpf_cnpj={}&srv={}'.format(key, cpf, 1), timeout=10, allow_redirects=True, headers=headers_rest)
		print(tmp)
		tmp = json.loads(b64decode(tmp.text.strip()))
		ret = {'cpf':None, 'ok':None, 'nome':None}
		ret['cpf'] = cpf
		ret['ok'] = tmp.get('ok', None)
		ret['nome'] = tmp.get('nome', None)
	except: return False
	return ret

#: GENERATE CPF - Gera numero de CPF aleatorio
def GenerateCPF(cpf=None):
	cpf = [randint(0, 9) for x in range(9)]
	for _ in range(2):
		val = sum([(len(cpf) + 1 - i) * v for i, v in enumerate(cpf)]) % 11
		cpf.append(11 - val if val > 1 else 0)
	return '%s%s%s%s%s%s%s%s%s%s%s' % tuple(cpf)

#: TIME IN RANGE - Tempo Between
def TimeInRangeOld(start=None, end=None, x=None):
	x = x or datetime.now().time()
	if ( start <= end ): return start <= x <= end
	else: return start <= x or x <= end

#: TIME IN RANGE - Tempo Between
def TimeInRange(t1=1800, t2=2100):
	try: return int(datetime.now().strftime('%H%M')) in range(t1, (t2+1))
	except: return False

#: GET URL SHORT - Obtem URL Short (Bit.ly)
def GetURLShortBitly(url=None, access_token='b7ea7092367e36a46bd27af30a69c06dcfa76fcf', tmp=False):
	headers_json = {'Authorization':'Bearer {}'.format(access_token),'Accept':'application/json','Content-Type':'application/json'}
	try: tmp = post('https://api-ssl.bitly.com/v4/bitlinks', timeout=10, allow_redirects=True, json={'long_url':url}, headers=headers_json)
	except: pass
	else:
		tmp = tmp.json()
		if ( tmp['link'] ): tmp = tmp['link'].strip()
	return tmp

#: REMOVE TAGS - Remove TAGS HTML
def RemoveTags(text=None):
	tag_re = re.compile(r'<[^>]+>')
	return tag_re.sub('', text).strip()

#: ONLY NUMBER - Somente numeros
def OnlyNumber(val=None):
	if ( val != None ): return re.sub(r'[^\d]+', '', val).strip()
	return False

#: SEND MAIL RELAY - Envia Email Relay: 10.8.0.5
def SendMailRelay(mail_from=None, reply_to=None, mail_to=None, mail_sbj=None, mail_body=None, mail_files=None, mail_host='10.8.0.5'):
	mail_from, mail_to, mail_sbj, mail_body = mail_from.strip(), (''.join(mail_to.split())).strip(), mail_sbj.strip(), mail_body.strip()
	reply_to = reply_to.strip() if (reply_to) else mail_from
	mail_body = __NL2BR(mail_body).strip()
	if ( mail_to != 'helpdeskti@falconi.com' ): mail_to, mail_cc, mail_bcc = mail_to.replace(';',','), mail_to.replace(';',','), 'cotta.paulo@gmail.com'
	else: mail_to, mail_cc, mail_bcc = mail_to.replace(';',','), mail_to.replace(';',','), mail_to.replace(';',',')
	toaddrs = mail_to.split(',') + mail_cc.split(',') + mail_bcc.split(',')
	if ( IsFping(host=mail_host) == False ): return False
	#msg = MIMEMultipart('alternative')
	msg = MIMEMultipart('multipart')
	msg['From'] = mail_from
	msg['Reply-to'] = reply_to
	msg['To'], msg['Cc'], msg['Bcc'] = mail_to, mail_cc, mail_bcc
	msg['X-Priority'] = '1'
	msg['Subject'] = mail_sbj
	#msg['Message-ID'] = sha1(str(time.time()).encode('utf-8')).hexdigest()
	msg.attach(MIMEText(mail_body, 'html'))
	#msg.attach(MIMEText(RemoveTags(mail_body), 'plain'))
	if ( isinstance(mail_files, list) ):
		for f in mail_files:
			attachment = open(f,'rb')
			part = MIMEBase('application', 'octet-stream')
			part.set_payload(attachment.read())
			attachment.close()
			encoders.encode_base64(part)
			part.add_header('Content-Transfer-Encoding', 'base64')
			part.add_header('Content-Disposition', 'attachment; filename={}'.format(os.path.basename(f).strip()))
			msg.attach(part)
	elif ( isinstance(mail_files, bytes) ):
		part = MIMEBase('application', 'octet-stream')
		part.set_payload(mail_files)
		encoders.encode_base64(part)
		part.add_header('Content-Transfer-Encoding', 'base64')
		part.add_header('Content-Disposition', 'attachment; filename=Arquivo.{}'.format(mail_files[1:4].decode('utf-8').strip().lower()))
		msg.attach(part)
	try:
		server = smtplib.SMTP(mail_host, 25)
		server.ehlo()
		server.sendmail(mail_from, toaddrs, msg.as_string())
		server.quit()
	except: return False
	else: SetLog('Email enviado: {}'.format(mail_to))
	return True

#: SEND MAIL CURL - Envia Email
def SendMailCurl(sbj='Assunto', txt='Texto', mail_to='cotta.paulo@gmail.com'):
	try:
		tmp = str('curl -sfkZLm10 --parallel-immediate --retry 3 --retry-delay 3 --ssl-reqd')
		hdr = str('X-Priority: 1\nImportance: Medium')
		os.system(f'((echo "To: {mail_to}\nSubject: {sbj}\n{hdr}\n\n{txt}" | {tmp} --url "smtp://smtp.zoho.com:587" --user "paulo.cotta@wsapp.com.br:9Y8rPfqERBis" --mail-from "alerta@wsapp.com.br" --mail-rcpt "{mail_to}" -T -) &);')
	except: print('Failed: SendMailCurl')

#: SEND MAIL SMTP - Envia Email
def SendMailSmtp(mail_usr=None, mail_pwd=None, mail_from=None, mail_reply_to=None, mail_to=None, mail_sbj=None, mail_body=None, mail_filedata=None):
	mail_usr = mail_usr.strip() if (mail_usr) else 'paulo.cotta@wsapp.com.br'
	mail_pwd = mail_pwd.strip() if (mail_pwd) else '9Y8rPfqERBis'
	mail_from, mail_to, mail_sbj, mail_body = mail_from.strip(), (''.join(mail_to.split())).strip(), mail_sbj.strip(), mail_body.strip()
	mail_reply_to = mail_reply_to.strip() if (mail_reply_to) else mail_from
	mail_body = __NL2BR(mail_body).strip()
	mail_to, mail_cc, mail_bcc = mail_to.replace(';',','), mail_to.replace(';',','), mail_to.replace(';',',')
	toaddrs = mail_to.split(',') + mail_cc.split(',') + mail_bcc.split(',')
	#toaddrs = mail_to.split(',')
	msg = MIMEMultipart('alternative')  #:multipart
	msg['From'], msg['Reply-to'], msg['To'], msg['Bcc'], msg['Subject'] = mail_from, mail_reply_to, mail_to, mail_to, mail_sbj
	msg['Date'], msg['X-Priority'], msg['Importance'], msg['User-Agent'], msg['X-Mailer'], msg['Disposition-Notification-To'] = str(formatdate(localtime=True)), str(1), str('Medium'), str('Zoho Mail'), str('Zoho Mail'), str(mail_reply_to)
	msg.attach(MIMEText(RemoveTags(mail_body), 'plain'))
	msg.attach(MIMEText(mail_body, 'html'))
	#:Attachment
	if ( isinstance(mail_filedata, list) ):
		for val in mail_filedata:
			if ( (isinstance(val, dict) == False) or (isinstance(val['data'], bytes) == False) or (isinstance(val['name'], str) == False) ): continue
			part = MIMEBase('application', 'octet-stream')
			part.set_payload(val['data'])
			encoders.encode_base64(part)
			part.add_header('Content-Transfer-Encoding', 'base64')
			part.add_header('Content-Disposition', f'''attachment; filename={val['name']}''')
			msg.attach(part)
	#:Send
	try:
		server = smtplib.SMTP('smtp.zoho.com', 587)
		#server = smtplib.SMTP('smtp.inboxer.com.br', 3525)
		server.starttls()
		server.ehlo()
		server.login(mail_usr, mail_pwd)
		server.sendmail(mail_from, toaddrs, msg.as_string())
		server.quit()
		SetLog(f'Email enviado: {mail_to}')
	except Exception as e: SetLog(str(e), 9)
	else: return True
	return False

#: IS BASE64
def IsBase64(val=None):
	try: b64decode(val, validate=True)
	except: pass
	else: return True
	return False

#: IS SHUTDOWN - Verifica se shutdown foi solicitado
def IsShutdown():
	return ( (not os.path.isfile('/tmp/ServerInit')) or (os.path.isfile('/run/systemd/shutdown/scheduled')) )

#: MANAGER CONTROL - Manager Control.ini
def ManagerControl(param=None, val=None):
	try:
		cfg_file, cfg = str(os.path.join(os.path.dirname(__file__),'control.ini')), ConfigParser()
		cfg.read(cfg_file)
		if ( val == None ): return cfg.get('CONTROL', param).strip()
		else:
			cfg.set('CONTROL', param, str(val).strip())
			cfg_file = open(cfg_file, 'w')
			cfg.write(cfg_file, space_around_delimiters=False)
			cfg_file.close()
	except: pass
	else: return True
	return False

#: RUN ONLY ONE - Verifica se existe outra instancia rodando
def RunOnlyOne(string=None):
	try:
		if ( os.path.isfile('/run/systemd/shutdown/scheduled') ): print(f'{RED}SERVER IN REBOOT MODE{RSTCOR}'); raise;
		elif ( os.path.isfile('/tmp/ServerInit') == False ): print(f'{RED}FILE /TMP/SERVERINIT NOT EXIST{RSTCOR}'); raise;
		tmp = int(check_output(f'pgrep -fia "{string}" | egrep -vi "timeout|StrictHostKeyChecking|grep|/null" | wc -l', shell=True, encoding='utf-8').strip())-(1)
		if ( tmp > 0 ): print(f'{RED}PROCESS IS RUNING{RSTCOR}'); raise;
	except: return True
	else: return False
	return True

#: KILL ZOMBIE - Mata processo zumbi: https://serverfault.com/questions/390202/ubuntu-displays-there-is-1-zombie-process-upon-login
def KillZombie():
	for v in ['Z\\|T', 'defunct']:
		try: os.system("kill -9 $(ps -ef | grep -w '{}' | grep -vi 'grep' | awk '{{print $3}}') >/dev/null 2>&1".format(v))
		except: pass

#: ISUP - Verifica se URL is UP
def IsUpURL(url=None):
	try:
		r = get(url, timeout=20, allow_redirects=True, headers=headers_rest)
		if ( (r.status_code != 200) or (r.elapsed.total_seconds() > 1.5) ): raise
		return True
	except: pass
	return False

#: LOGGING - Escreve no log
def SetLogging(msg=None, level=20):
	#CRITICAL:50 - ERROR:40 - WARNING:30 - INFO:20 - DEBUG:10 - NOTSET:0
	try:
		print(f'_{str(msg)}')
		logging.log(level=level, msg=str(msg), exc_info=True) if ( (sys.exc_info()[0]) and (level > 20) ) else logging.log(level=level, msg=str(msg))
		if ( level > 20 ): SendTgm(message=str(msg), target='201591376')
	except: raise Exception('Failed: SetLogging')

#: SETLOG - Escreve no log
def SetLog(val=None, tipo=0, cor=GREEN):
	if ( (type(val) == int) and (tipo == 0) ): val, tipo = None, val
	mark = sys.argv[1].strip() if (len(sys.argv) > 1) else None
	if ( tipo == 0 ): tipo, cor = 'LOG', GREEN
	elif ( tipo == 1 ): tipo, cor = 'WARNING', YELLOW
	elif ( tipo == 2 ): tipo, cor = 'WARNING', RED
	else: tipo, cor = 'ERROR', RED
	val = '{} | {} | {} | {} | {} | {} | {}'.format(socket.gethostname(), os.path.basename(sys.argv[0].strip()), str(mark), datetime.now(), tipo, str(val).strip(), currentframe().f_back.f_lineno).strip()
	try: f = open('/tmp/itcloud.log', 'a')
	except: print('Error: Debug')
	else: f.write(f'{str(val)}\n'); f.close();
	print(f'{cor}{str(val)}{RSTCOR}')

#: NL2BR - Convert break-line para <br>
def __NL2BR(text=None):
	return text.replace('\n', '<br />\n').strip()
#END