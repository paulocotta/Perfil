#!/bin/bash
(sleep 5 && printenv > '/tmp/container.env' && touch '/tmp/ServerInit') >/dev/null 2>&1;
(ln -sf '/usr/share/zoneinfo/America/Sao_Paulo' '/etc/localtime') >/dev/null 2>&1;
(chmod -fR 0644 '/etc/cron.d/' '/etc/crontab' '/etc/environment') >/dev/null 2>&1;
(chmod -fR 0755 '/usr/bin/entrypoint.sh') >/dev/null 2>&1;
(chmod -fR 0755 '/aplication') >/dev/null 2>&1;
(sed -i -e 's/# en_US.UTF-8 UTF-8/en_US.UTF-8 UTF-8/' '/etc/locale.gen' && sed -i -e 's/# pt_BR.UTF-8 UTF-8/pt_BR.UTF-8 UTF-8/' '/etc/locale.gen' && locale-gen) >/dev/null 2>&1;
sleep infinity;
while true; do
	[ $(ps aux | egrep -vi 'grep|/null' | egrep -csi 'rotinas-api') -eq 0 ] && { ((timeout 12h python3.8 '/mnt/Data/01_Dropbox/RotinasSrv/srv-ovh-01/scripts/rotinas-api.py') &) >/dev/null 2>&1; }
	sleep 60;
done
exit 0;